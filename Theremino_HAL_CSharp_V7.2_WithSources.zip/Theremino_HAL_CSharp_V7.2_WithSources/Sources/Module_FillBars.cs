using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
namespace Theremino_HAL
{
	static class Module_FillBars
	{

		// =======================================================================================
		//  FILL PICTURE BOX - WITH SINGLE COLOR
		// =======================================================================================
		public static void FillPictureBox(PictureBox pbox, 
                                            double value, 
                                            Color c1, 
                                            Color c2)
		{
			// ------------------------------------------------------- using a bitmap for best performance
			if (pbox.Image == null) 
            {
                Module_ImageFilters.InitPictureboxImage(pbox);
			}
			// -------------------------------------------------------
			if (double.IsNaN(value)) value = 0; 
			if (value < 0) value = 0; 
			if (value > 1) value = 1;
            Int32 v = Convert.ToInt32(value * pbox.ClientSize.Width);
			// ------------------------------------------------------- using "Graphics.FromImage" for best performance
			Graphics g = Graphics.FromImage(pbox.Image);
			g.FillRectangle(new SolidBrush(c1), 0, 0, v, pbox.ClientSize.Height);
			g.FillRectangle(new SolidBrush(c2), v, 0, pbox.ClientSize.Width - v, pbox.ClientSize.Height);
			//
			// ------------------------------------------------------- final refresh - no flickering
			pbox.Invalidate();
		}

        public static void FillPictureBox_Horizontal(PictureBox pbox, double value, Color c1, Color c2, double MarkPoint)
		{
			// ------------------------------------------------------- using a bitmap for best performance
			if (pbox.Image == null) 
            {
                Module_ImageFilters.InitPictureboxImage(pbox);
			}
			// -------------------------------------------------------
			if (double.IsNaN(value)) value = 0; 
			if (value < 0) value = 0; 
			if (value > 1) value = 1;
            Int32 v = Convert.ToInt32(value * pbox.ClientSize.Width);
			// ------------------------------------------------------- using "Graphics.FromImage" for best performance
            Graphics g = Graphics.FromImage(pbox.Image);

            g.FillRectangle(new SolidBrush(c1), 0, 0, v, pbox.ClientSize.Height);
            g.FillRectangle(new SolidBrush(c2), v, 0, pbox.ClientSize.Width - v, pbox.ClientSize.Height);
			//
			// ------------------------------------------------------- final refresh - no flickering
            pbox.Refresh();
		}

	}
}
