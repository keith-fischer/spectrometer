using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace Theremino_HAL
{

    static class ThereminoSystem
    {

	    public static bool ConfigurationIsValid = false;
        public static List<Master> Masters;
        public static Stopwatch FreeRunningTimer = new Stopwatch();

        public static void TheSystem_InitMasters()
	    {
            // ------------------------------------------------
            FreeRunningTimer.Start();
            // -------------------------------------------------
	        if (Masters != null) 
            {
		        //For Each m As Master In Masters
		        //    '    If m.Hid.HidDevice_Unix.IsHidOpen() Then
		        //    '        m.Hid.HidDevice_Unix.HidClose()
		        //    '    End If
		        //    'm.Hid = Nothing
		        //Next
		        Masters.Clear();
	        }
	        else 
            {
		        Masters = new List<Master>();
	        }

            if (Theremino.OperatingSystemIsWindows)
            {
			    Theremino_HID.FindThereminoHids(false);
		    }
		    else 
            {
                Theremino_HID.FindThereminoHids_Unix(false);
		    }
            // -------------------------------------------- read Master names
            Int32 i = 0;
            while (((i >= 0) && (i < Masters.Count)))
            {
                //  --------------------------------------- read name two times to detect if the Master is already used
                Masters[i].ReadNameFromHardware();
                string name1 = Masters[i].GetName();
                Masters[i].ReadNameFromHardware();
                string name2 = Masters[i].GetName();
                Masters[i].ReadNameFromHardware();
                string name3 = Masters[i].GetName();
                //  --------------------------------------- if there are ValidMasterNames then test the Master-name 
                if (Module_SaveLoad.ValidMasterNames.Length > 0)
                {
                    if (Array.IndexOf(Module_SaveLoad.ValidMasterNames, Masters[i].GetName()) < 0)
                    {
                        Masters.Remove(Masters[i]);
                        i--;
                    }
                }
                else
                {
                    //  --------------------------------------- if a Master is used by another HAL then release it 
                    if (name1 != name2 | name2 != name3)
                    {
                        Masters.Remove(Masters[i]);
                        i--;
                    }
                }
                // --------------------------------------------- increase the while index
                i++;
            }

            // ------------------------------------------------ Sort Masters
            Masters.Sort(MasterComparer);

            // -------------------------------------------------
            SetAllMasterId();
	    }

        private static int MasterComparer(Master m1, Master m2)
        {
            return String.Compare(m1.GetName(), m2.GetName(), true);
        }

        public static void TheSystem_ReconnectMasters()
        {
            if (Theremino.OperatingSystemIsWindows)
            {
                Theremino_HID.FindThereminoHids(true);
            }
            else
            {
                Theremino_HID.FindThereminoHids_Unix(true);
            }
            TheSystem_ListComponents();
            My.MyProject.Forms.Form1.ListView_SetAllLineColors();
        }

        public static void TheSystem_DisconnectMaster(Master m)
	    {
            Masters.Remove(m);
            SetAllMasterId();
        }

        private static void SetAllMasterId()
	    {
           for (Int32 i = 0; i < Masters.Count; i++)
            {
                Masters[i].MasterId = i;
                foreach (Slave s in Masters[i].Slaves)
                {
                    s.MasterId = i;
                    foreach (Pin p in s.Pins)
                    {
                        p.MasterId = i;
                    }
                }
            }
        }

        public static void TheSystem_StartTimers()
	    {
            if (!ThereminoSystem.ConfigurationIsValid) return;
 
		    foreach (Master m in Masters) 
            {
			    m.StartTimedOperations();
		    }
	    }

        public static void TheSystem_StopTimers()
	    {
		    foreach (Master m in Masters) 
            {
			    m.StopTimedOperations();
		    }
	    }

        public static void TheSystem_RecognizeSlaves()
	    {
		    foreach (Master m in Masters) 
            {
			    m.Recognize();
		    }

		    AssignDefaultSlotsToPins();
		    AssignConfigurationsToMasters();
		    SetConfigurationParamsToDevices();

            // ------------------------------------- remove adc24 redundant pins
            foreach (Master m in Masters)
            {
                if (m.Slaves.Count > 0)
                {
                    if (m.MasterFirmwareVersion >= 50 && m.Slaves[0].SlaveType == Slave.SlaveTypes.MasterPinsV4)
                    {
                        (m.Slaves[0] as Slave_MasterPinsV4).Adc24_AddRemovePins();
                    }
                }
            }
            TestConfigErrors();

		    My.MyProject.Forms.Form1.SelectedLine = -1;
		    TheSystem_ListComponents();
		    My.MyProject.Forms.Form1.ListView_SetAllLineColors();
		    MarkErrorLines();
            My.MyProject.Forms.Form1.ToolStripButton_Validate.Enabled = !ThereminoSystem.ConfigurationIsValid;
		    My.MyProject.Forms.Form1.EnableCalibrateButton(TheSystem_CalibrationNeeded());
		   
		    TheSystem_Calibrate();
	    }

	    private static void AssignDefaultSlotsToPins()
	    {
		    Int32 i = 1;
		    foreach (Master m in Masters) 
            {
			    Int32 j = i;
			    i += 100;
			    foreach (Slave s in m.Slaves) 
                {
				    foreach (Pin p in s.Pins) 
                    {
					    p.Slot = j;
					    j += 1;
				    }
			    }
		    }
	    }

        public static bool TheSystem_CalibrationNeeded()
	    {
		    foreach (Master m in Masters) 
            {
			    if (m.CalibrationNeeded()) return true; 
		    }
            return false;
	    }

        public static void TheSystem_Calibrate()
	    {
		    foreach (Master m in Masters) 
            {
			    m.Calibrate();
		    }
	    }

        public static void TheSystem_CalibrateZero()
	    {
		    foreach (Master m in Masters) 
            {
			    m.CalibrateZero();
		    }
	    }

        public static void TheSystem_SetParkingPositions()
	    {
		    foreach (Master m in Masters) 
            {
			    m.SetOutputPinsToParkingPosition();
		    }
	    }

        public static Int32 TheSystem_GetSlaveCount()
	    {
		    Int32 sc = 0;
		    foreach (Master m in Masters) 
            {
			    sc += m.SlaveCount;
		    }
		    return sc;
	    }

        public static Master GetMasterByListLine(Int32 line, string LineType)
	    {
		    Master m = null;
		    Slave s = null;
		    Pin p = null;
		    //
		    switch (LineType) 
            {
			    case "Master":
                    m = ThereminoSystem.FindMasterByListLine(line);
				    break;
			    case "Slave":
                    s = ThereminoSystem.FindSlaveByListLine(line);
				    if (s != null) m = Masters[s.MasterId];
				    break;
			    case "Pin":
                case "Adc24":
                    p = ThereminoSystem.FindPinByListLine(line);
                    if (p != null) m = Masters[p.MasterId];
				    break;
		    }
		    //
		    return m;
	    }

	    private static Master FindMasterByListLine(Int32 line)
	    {
		    Int32 n = 0;
		    foreach (Master m in Masters) 
            {
			    if (n == line) return m; 
			    n += 1;
			    foreach (Slave s in m.Slaves) 
                {
				    n += 1;
				    foreach (Pin p in s.Pins) 
                    {
					    n += 1;
				    }
			    }
		    }
		    return null;
	    }

	    private static Slave FindSlaveByListLine(Int32 line)
	    {
		    Int32 n = 0;
		    foreach (Master m in Masters) 
            {
			    n += 1;
			    foreach (Slave s in m.Slaves) 
                {
				    if (n == line) return s; 
				    n += 1;
				    foreach (Pin p in s.Pins) 
                    {
					    n += 1;
				    }
			    }
		    }
		    return null;
	    }

        public static Pin FindPinByListLine(Int32 line)
	    {
		    Int32 n = 0;
		    foreach (Master m in Masters) 
            {
			    n += 1;
			    foreach (Slave s in m.Slaves) 
                {
				    n += 1;
				    foreach (Pin p in s.Pins) 
                    {
					    if (n == line) return p; 
					    n += 1;
				    }
			    }
		    }
		    return null;
	    }

        public static Pin GetSelectedPin()
	    {
		    return FindPinByListLine(My.MyProject.Forms.Form1.SelectedLine);
	    }

        public static Int32 GetSelectedListLine()
        {
            return My.MyProject.Forms.Form1.SelectedLine;
        }


	    // ==================================================================================================
	    //   LIST COMPONENTS
	    // ==================================================================================================
        public static void TheSystem_ListComponents()
	    {
            Module_SaveLoad.LoadSlotNames();

		    ListViewItem item = null;
		    {
			    My.MyProject.Forms.Form1.MyListView1.GridLines = true;
			    My.MyProject.Forms.Form1.MyListView1.FullRowSelect = true;
			    My.MyProject.Forms.Form1.MyListView1.Header_BackColor1 = Color.FromArgb(255, 255, 200);
			    My.MyProject.Forms.Form1.MyListView1.Header_BackColor2 = Color.FromArgb(200, 200, 200);
			    My.MyProject.Forms.Form1.MyListView1.Header_ForeColor = Color.FromArgb(20, 20, 20);
			    My.MyProject.Forms.Form1.MyListView1.Header_ShadowColor = Color.FromArgb(255, 255, 255);
                My.MyProject.Forms.Form1.MyListView1.Header_Font = new Font("Tahoma", 9, FontStyle.Regular);
			    My.MyProject.Forms.Form1.MyListView1.Font = new Font("Courier new", 8);
			    My.MyProject.Forms.Form1.MyListView1.View = View.Details;
			    My.MyProject.Forms.Form1.MyListView1.Clear();
			    // ----------------------------------------------------------------- column headers
			    My.MyProject.Forms.Form1.MyListView1.Columns.Add("Type", 56, HorizontalAlignment.Left);
			    //55
			    My.MyProject.Forms.Form1.MyListView1.Columns.Add("ID", 28, HorizontalAlignment.Left);
			    My.MyProject.Forms.Form1.MyListView1.Columns.Add("Subtype", 105, HorizontalAlignment.Left);
			    My.MyProject.Forms.Form1.MyListView1.Columns.Add("Dir.", 36, HorizontalAlignment.Left);
			    //35
			    My.MyProject.Forms.Form1.MyListView1.Columns.Add("Slot", 35, HorizontalAlignment.Center);
			    My.MyProject.Forms.Form1.MyListView1.Columns.Add("Value", 62, HorizontalAlignment.Right);
			    My.MyProject.Forms.Form1.MyListView1.Columns.Add("Notes", 100, HorizontalAlignment.Left);
			    My.MyProject.Forms.Form1.MyListView1.Refresh();
			    // -----------------------------------------------------------------
                if (Theremino.OperatingSystemIsWindows)
                {
                    My.MyProject.Forms.Form1.MyListView1.SetExtStyle_DoubleBuffering();
                }
                // -----------------------------------------------------------------
			    foreach (Master m in Masters) 
                {
				    item = My.MyProject.Forms.Form1.MyListView1.Items.Add("Master");
				    item.SubItems.Add((m.MasterId + 1).ToString());
				    item.SubItems.Add(m.GetName());
				    item.SubItems.Add("");
				    item.SubItems.Add("");
				    item.SubItems.Add("");
				    item.SubItems.Add("");
				    foreach (Slave s in m.Slaves) 
                    {
					    item = My.MyProject.Forms.Form1.MyListView1.Items.Add(" Slave");
					    item.SubItems.Add((s.SlaveId + 1).ToString());
					    item.SubItems.Add(s.SlaveTypeString());
					    item.SubItems.Add("");
					    item.SubItems.Add("");
					    item.SubItems.Add("");
                        if (s.SlaveId == 0) 
                        {
                            item.SubItems.Add("Firmware V" + s.FirmwareVersion());
                        }
                        else 
                        {
                            item.SubItems.Add("");
                        }
					    foreach (Pin p in s.Pins) 
                        {
                            if (p.PinId < 12)
                            {
                                item = My.MyProject.Forms.Form1.MyListView1.Items.Add("   Pin");
                                item.SubItems.Add((p.PinId + 1).ToString());
                            }
                            else
                            {
                                item = My.MyProject.Forms.Form1.MyListView1.Items.Add(" Adc24");
                                item.SubItems.Add((p.PinId - 11).ToString());
                            }

						    item.SubItems.Add(Pin.PinTypeToString(p.GetPinType()));
						    item.SubItems.Add(p.GetDirectionString());
                            if (p.Direction != Pin.Directions.Unused) 
                            {
							    item.SubItems.Add(p.Slot.ToString());
							    item.SubItems.Add("0.0");
						    }
						    else 
                            {
							    item.SubItems.Add("");
							    item.SubItems.Add("");
						    }

                            if (p.GetPinType() == Pin.PinTypes.UNUSED)
                                item.SubItems.Add("");
                            else
                                item.SubItems.Add(Module_SaveLoad.SlotNames[p.Slot]);
					    }
				    }
			    }
                TheSystem_ListViewResize();
		    }
	    }

	    private static void MarkErrorLine(Int32 LineNumber)
	    {
		    {
			    My.MyProject.Forms.Form1.MyListView1.Items[LineNumber].SubItems[6].Text = "Found but not configured";
			    My.MyProject.Forms.Form1.MyListView1.Items[LineNumber].BackColor = Color.FromArgb(255, 150, 150);
			    My.MyProject.Forms.Form1.MyListView1.Items[LineNumber].ForeColor = Color.Black;
		    }
	    }

	    private static void AddErrorLine(string[] config, Int32 LineNumber)
	    {
		    {
			    ListViewItem item = null;
			    string[] s = config[LineNumber].Split(',');
			    item = My.MyProject.Forms.Form1.MyListView1.Items.Add(s[0]);
			    item.SubItems.Add("");
			    item.SubItems.Add(s[1]);
			    item.SubItems.Add("");
			    item.SubItems.Add("");
			    item.SubItems.Add("");
			    item.SubItems.Add("Configured but not found");
			    item.BackColor = Color.FromArgb(255, 80, 50);
			    item.ForeColor = Color.White;
		    }
	    }

        public static void TheSystem_ListViewResize()
	    {
		    ResizeLastColumn();
	    }

	    private static void ResizeLastColumn()
	    {
            //if (My.MyProject.Forms.Form1.MyListView1.Columns.Count > 1)
            //{
            //    // --------------------------------------------------------- last column
            //    Int32 w = 0;
            //    for (Int32 i = 0; i <= My.MyProject.Forms.Form1.MyListView1.Columns.Count - 2; i++) {
            //        w += My.MyProject.Forms.Form1.MyListView1.Columns[i].Width;
            //    }
            //    w = My.MyProject.Forms.Form1.MyListView1.ClientSize.Width - w - 2;
            //    if (!ConfigurationIsValid)
            //    {
            //        w = Math.Max(w, 200);
            //    }
            //    My.MyProject.Forms.Form1.MyListView1.Columns[My.MyProject.Forms.Form1.MyListView1.Columns.Count - 1].Width = w;
            //}

            Int32 n = My.MyProject.Forms.Form1.MyListView1.Columns.Count;
            if (n > 1) 
            {
                My.MyProject.Forms.Form1.MyListView1.Columns[n - 1].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
	    }


	    // ==================================================================================================
	    //   LIST COMPONENTS - UPDATE VALUES
	    // ==================================================================================================
        public static void TheSystem_UpdateListedSubtypes()
	    {
		    string str = null;
		    {
			    Int32 n = 0;
			    foreach (Master m in Masters) 
                {
				    if (m.GetName() != My.MyProject.Forms.Form1.MyListView1.Items[n].SubItems[2].Text) My.MyProject.Forms.Form1.MyListView1.Items[n].SubItems[2].Text = m.GetName(); 
				    n += 1;
				    foreach (Slave s in m.Slaves) 
                    {
					    str = s.SlaveTypeString();
					    if (str != My.MyProject.Forms.Form1.MyListView1.Items[n].SubItems[2].Text) My.MyProject.Forms.Form1.MyListView1.Items[n].SubItems[2].Text = str; 
					    n += 1;
					    foreach (Pin p in s.Pins) 
                        {
						    str = Pin.PinTypeToString(p.GetPinType());
						    if (str != My.MyProject.Forms.Form1.MyListView1.Items[n].SubItems[2].Text) My.MyProject.Forms.Form1.MyListView1.Items[n].SubItems[2].Text = str; 
						    n += 1;
					    }
				    }
			    }
		    }
	    }

        public static void TheSystem_TestMasterError()
        {
            bool MasterError = false;
            foreach (Master m in Masters)
            {
                if (!m.Hid.MyDeviceDetected)
                {
                    MasterError = true;
                }
            }
            if (MasterError)
            {
                ThereminoSlots.WriteSlot(0, Theremino.NAN_MasterError);
            }
            else
            {
                ThereminoSlots.WriteSlot(0, 0);
            }
        }


        public static void TheSystem_UpdateListedValues()
	    {
		    System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo("en-GB");
		    string str = null;
		    {
			    Int32 n = 0;
			    foreach (Master m in Masters) 
                {
				    if (!m.Hid.MyDeviceDetected) 
                    {
					    My.MyProject.Forms.Form1.MyListView1.Items[n].SubItems[6].Text = "DISCONNECTED";
					    My.MyProject.Forms.Form1.MyListView1.Items[n].BackColor = Color.FromArgb(255, 150, 150);
					    My.MyProject.Forms.Form1.MyListView1.Items[n].ForeColor = Color.Black;
				    }
				    n += 1;
				    foreach (Slave s in m.Slaves) 
                    {
					    n += 1;
					    foreach (Pin p in s.Pins) 
                        {
						    if (p.Direction != Pin.Directions.Unused) 
                            {
							    if (float.IsNaN(p.Value)) 
                                {
                                    str = Theremino.NAN_GetName(p.Value);
							    }
							    else 
                                {
								    str = p.Value.ToString("0.0", ci);
							    }
							    if (str != My.MyProject.Forms.Form1.MyListView1.Items[n].SubItems[5].Text) My.MyProject.Forms.Form1.MyListView1.Items[n].SubItems[5].Text = str; 
						    }
						    n += 1;
					    }
				    }
			    }
		    }
	    }


	    // ==================================================================================================
	    //   CONFIGURATIONS
	    // ==================================================================================================

	    public static object[] ConfigDatabase;
	    private static void MarkErrorLines()
	    {
		    string[] config = new string[-1 + 1];
		    //

		    foreach (Master m in Masters) 
            {
			    if (m.ConfigValid) continue; 

			    Int32 n = 0;
			    string[] sa = null;
			    //
			    if (ConfigDatabase.Length > 0) 
                {
				    config = ConfigDatabase[m.ConfigId] as string[];
			    }

			    // TODO
			    // if already axists another master with the same name then
			    //m.ConfigValid = False

			    if (n < config.Length) 
                {
				    sa = config[n].Split(',');
				    if (sa.Length < 2 || sa[0].Trim() != "Master" || sa[1].Trim() != m.GetName()) {
					    MarkErrorLine(n);
				    }
			    }
			    else {
				    MarkErrorLine(n);
			    }
			    n += 1;
			    foreach (Slave s in m.Slaves) 
                {
				    if (n < config.Length) 
                    {
					    sa = config[n].Split(',');
					    if (sa.Length < 2 || sa[0].Trim() != "Slave" || sa[1].Trim() != s.SlaveTypeString()) 
                        {
						    MarkErrorLine(n);
					    }
				    }
				    else {
					    MarkErrorLine(n);
				    }
				    n += 1;
				    foreach (Pin p in s.Pins) 
                    {
					    if (n < config.Length) 
                        {
						    sa = config[n].Split(',');
						    if (sa.Length < 2 || sa[0].Trim() != "Pin" || sa[1].Trim() != Pin.PinTypeToString(p.GetPinType())) 
                            {
							    MarkErrorLine(n);
						    }
					    }
					    else 
                        {
						    MarkErrorLine(n);
					    }
					    n += 1;
				    }
			    }
			    //
			    while ((n < config.Length)) 
                {
				    AddErrorLine(config, n);
				    n += 1;
			    }
		    }
	    }

	    private static Int32 CountConfigErrors(Master m, string[] Config)
	    {
		    Int32 Errors = 0;
		    Int32 n = 0;
		    string[] sa = null;
		    //
		    if (n < Config.Length) 
            {
			    sa = Config[n].Split(',');
			    //OrElse sa[1].Trim <> m.Name Then
			    if (sa.Length < 2 || sa[0].Trim() != "Master") 
                {
				    Errors += 1;
			    }
		    }
		    else {
			    Errors += 1;
		    }
		    n += 1;
		    foreach (Slave s in m.Slaves) 
            {
			    if (n < Config.Length)
                {
				    sa = Config[n].Split(',');
				    if (sa.Length < 2 || sa[0].Trim() != "Slave" || sa[1].Trim() != s.SlaveTypeString()) 
                    {
					    Errors += 1;
				    }
			    }
			    else {
				    Errors += 1;
			    }
			    n += 1;
			    foreach (Pin p in s.Pins) 
                {
				    if (n < Config.Length) 
                    {
					    sa = Config[n].Split(',');
					    if (sa.Length < 2 || sa[0].Trim() != "Pin") 
                        {
						    Errors += 1;
					    }
				    }
				    else 
                    {
					    Errors += 1;
				    }
				    n += 1;
			    }
		    }
		    //
		    if (Config.Length > n) 
            {
			    Errors += (Config.Length - n);
		    }
		    //
		    return Errors;
	    }

	    public static string GetConfigName(string[] config)
	    {
		    string[] sa = null;
		    sa = config[0].Split(',');
		    if (sa.Length > 1) 
            {
			    return sa[1].Trim();
		    }
		    else 
            {
			    return "";
		    }
	    }

	    public static Int32 FindConfigByName(string name)
	    {
		    for (Int32 i = 0; i <= ConfigDatabase.Length - 1; i++) 
            {
			    if (name.ToUpper() == GetConfigName(ConfigDatabase[i] as string[]).ToUpper()) 
                {
				    return i;
			    }
		    }
		    return -1;
	    }

        public static void FillConfigNamesCombo(ComboBox cmb)
        {
            for (Int32 i = 0; i <= ConfigDatabase.Length - 1; i++)
            {
                cmb.Items.Add(GetConfigName(ConfigDatabase[i] as string[]));
            }
        }

	    private static void AssignConfigurationsToMasters()
	    {
		    //
            ThereminoSystem.ConfigurationIsValid = true;
		    //
		    for (Int32 i = 0; i <= Masters.Count - 1; i++) 
            {
			    Masters[i].ConfigValid = true;
			    // ----------------------------------------------------------- find configuration by name
			    Masters[i].ConfigId = FindConfigByName(Masters[i].GetName());
			    // ----------------------------------------------------------- if not found add a new configuration
			    if (Masters[i].ConfigId < 0) 
                {
				    Masters[i].ConfigId = ConfigDatabase.Length;
				    string[] config = CreateConfig_AsStringArray(Masters[i]);
                    AddToConfigDatabase(config);
                    TheSystem_SaveConfigDatabase();
			    }
		    }
	    }

        private static void TestConfigErrors()
        {
            for (Int32 i = 0; i <= Masters.Count - 1; i++)
            {
                if (CountConfigErrors(Masters[i], ThereminoSystem.ConfigDatabase[Masters[i].ConfigId] as string[]) > 0)
                {
                    Masters[i].ConfigValid = false;
                    ConfigurationIsValid = false;
                }
            }
        }

	    private static void SetConfigurationParamsToDevices()
	    {
		    string[] sa = null;
		    foreach (Master m in Masters)
            {
			    if (m.ConfigId >= ConfigDatabase.Length) continue; 
			    string[] config = ConfigDatabase[m.ConfigId] as string[];
			    if (config == null) continue; 
			    Int32 nline = 0;
			    if (nline >= config.Length) continue; 
			    sa = config[nline].Split(',');
			    nline += 1;
			    if (sa.Length == 4) 
                {
				    m.SetSpeed((int)Conversion.Val(sa[2].Trim()));
                    if (m.Slaves.Count > 1)
                    {
				        m.FastComm = sa[3].Trim() == "True";
                    }
                    else
                    {
                        m.FastComm = true;
                    }
			    }
			    foreach (Slave s in m.Slaves) 
                {
				    if (nline >= config.Length) continue; 
				    sa = config[nline].Split(',');
				    nline += 1;
				    foreach (Pin p in s.Pins) 
                    {
					    if (nline >= config.Length) continue; 
					    sa = config[nline].Split(',');
                        // -------------------------------------- if last pin, goto next slave
                        String ConfLineType = sa[0].Trim();
                        if (ConfLineType != "Pin") continue;
					    nline += 1;

					    Pin.PinTypes ConfPinType = Pin.StringToPinType(sa[1]);
					    if (ConfPinType != p.GetPinType()) 
                        {
						    s.ConfigurePin(p.PinId, ConfPinType);
					    }

					    if (sa.Length >= 6) {
						    p.Slot = (int)Conversion.Val(sa[2].Trim());
						    if (p.Slot > 999) p.Slot = 999; 
						    p.Value_Max = (float)Conversion.Val(sa[3].Trim());
						    p.Value_Min = (float)Conversion.Val(sa[4].Trim());
						    //
                            Int32 nn = (int)Conversion.Val(sa[5].Trim());
                            p.AdaptiveSpeed = false;
                            if (nn >= 1000)
                            {
                                p.AdaptiveSpeed = true;
                                nn -= 1000;
                            }
                            if (nn > 100) nn = 100;
                            if (nn < 1) nn = 1;
                            p.ResponseSpeed = nn;
                            //
						    switch (p.GetPinType()) 
                            {
                                case Pin.PinTypes.PWM_8:
                                case Pin.PinTypes.PWM_16:
                                    if (sa.Length >= 9)
                                    {
                                        p.MaxTime = (float)Conversion.Val(sa[6].Trim());
                                        p.MinTime = (float)Conversion.Val(sa[7].Trim());
                                        p.LogResponse = sa[8].Trim() == "True";
                                    }
                                    break;
							    case Pin.PinTypes.SERVO_8:
							    case Pin.PinTypes.SERVO_16:
								    if (sa.Length >= 8)
                                    {
									    p.MaxTime = (float)Conversion.Val(sa[6].Trim());
									    p.MinTime = (float)Conversion.Val(sa[7].Trim());
								    }
								    break;
                                case Pin.PinTypes.STEPPER:
                                    if (sa.Length >= 10)
                                    {
                                        p.MaxSpeed = (float)Conversion.Val(sa[6].Trim());
                                        p.MaxAcc = (float)Conversion.Val(sa[7].Trim());
                                        p.StepsPerMillimeter = (float)Conversion.Val(sa[8].Trim());
                                        p.LinkedToPrevious = sa[9].Trim() == "True";
                                    }
                                    break;
                                case Pin.PinTypes.PWM_FAST:
                                    if (sa.Length >= 10)
                                    {
                                        p.PwmFastFrequency = (float)Conversion.Val(sa[6].Trim());
                                        p.PwmFastDutyCycle = (float)Conversion.Val(sa[7].Trim());
                                        p.FrequencyFromSlot = sa[8].Trim() == "True";
                                        p.DutyCycleFromSlot = sa[9].Trim() == "True";
                                    }
                                    break;
							    case Pin.PinTypes.CAP_8:
							    case Pin.PinTypes.CAP_16:
								    if (sa.Length >= 8)
                                    {
									    p.MinVariation = (float)Conversion.Val(sa[6].Trim());
									    p.ProportionalArea = (float)Conversion.Val(sa[7].Trim());
								    }
								    break;
							    case Pin.PinTypes.USOUND_SENSOR:
								    if (sa.Length >= 9)
                                    {
									    p.MaxDist_mm = (float)Conversion.Val(sa[6].Trim());
									    p.MinDist_mm = (float)Conversion.Val(sa[7].Trim());
                                        p.RemoveErrors = sa[8].Trim() == "True";
								    }
								    break;
							    case Pin.PinTypes.CAP_SENSOR:
								    if (sa.Length >= 9)
                                    {
									    p.MaxDist_mm = (float)Conversion.Val(sa[6].Trim());
									    p.MinDist_mm = (float)Conversion.Val(sa[7].Trim());
									    p.Area_cmq = (float)Conversion.Val(sa[8].Trim());
								    }
								    break;
							    case Pin.PinTypes.COUNTER:
							    case Pin.PinTypes.COUNTER_PU:
							    case Pin.PinTypes.FAST_COUNTER:
							    case Pin.PinTypes.FAST_COUNTER_PU:
							    case Pin.PinTypes.PERIOD:
							    case Pin.PinTypes.PERIOD_PU:
                                case Pin.PinTypes.SLOW_PERIOD:
                                case Pin.PinTypes.SLOW_PERIOD_PU:
								    if (sa.Length >= 9)
                                    {
									    p.MaxFreq = (float)Conversion.Val(sa[6].Trim());
									    p.MinFreq = (float)Conversion.Val(sa[7].Trim());
									    p.ConvertToFreq = sa[8].Trim() == "True";
								    }
								    break;
                                case Pin.PinTypes.ADC_24:
                                    if (sa.Length >= 9)
                                    {
                                        p.Adc24Npins = (int)Conversion.Val(sa[6].Trim());
                                        p.Adc24Sps = (int)Conversion.Val(sa[7].Trim());
                                        p.Adc24Filter = (int)Conversion.Val(sa[8].Trim());
                                    }
                                    break;
                                case Pin.PinTypes.ADC_24_DIN:
                                case Pin.PinTypes.ADC_24_DOUT:
                                    break;
                                case Pin.PinTypes.ADC_24_CH:
                                case Pin.PinTypes.ADC_24_CH_B:
                                    if (sa.Length >= 9)
                                    {
                                        p.Adc24ChType = (int)Conversion.Val(sa[6].Trim());
                                        p.Adc24ChGain = (int)Conversion.Val(sa[7].Trim());
                                        p.Adc24ChBias = sa[8].Trim() == "True";
                                    }
                                    break;
                                case Pin.PinTypes.ENCODER_B:
                                case Pin.PinTypes.ENCODER_B_PU:
                                    break;
						    }
					    }
				    }

				    // -------------------------------------- re-align all the pins 
				    //If PinTypeChanged Then
				    m.SetupSlavePins(s.mSlaveId);
				    //End If


                    //  -------------------------------------- send special Pin configurations
                    if (s.SlaveId == 0) 
                    {
                        //  ------------------------------------- special STEPPER parameters
                        foreach (Pin p in s.Pins) 
                        {
                            if (p.GetPinType() == Pin.PinTypes.STEPPER) 
                            {
                                //  ------------------------------------------------------------------
                                //   STEPPER PIN CONFIGURATION - BY SendBytesToSlave
                                //  ------------------------------------------------------------------
                                p.SendStepperParamsToHardware();
                                //  ------------------------------------------------------------------
                            }
                        }
                        //  ------------------------------------- special ADC_24 parameters
                        if (m.MasterFirmwareVersion >= 50 && s.SlaveType == Slave.SlaveTypes.MasterPinsV4)
                        {
                            (s as Slave_MasterPinsV4).Adc24_AddRemovePins();
                            if (s.Pins[6].GetPinType() == Pin.PinTypes.ADC_24)
                            {
                                //  ------------------------------------------------------------------
                                //   ADC_24 PIN CONFIGURATION - BY SendBytesToSlave
                                //  ------------------------------------------------------------------
                                (s as Slave_MasterPinsV4).Adc24ConfigAndStart();
                            }
                        }
                    }

			    }
			    m.SetCommunicationIndexesToPins();
		    }
	    }

	    private static string[] CreateConfig_AsStringArray(Master m)
	    {
		    Int32 i = default(Int32);
            System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo("en-GB");
		    string[] config = new string[1];
		    config[0] = "Master";
		    config[0] += "," + m.GetName();
		    config[0] += "," + m.CommSpeed.ToString();
		    config[0] += "," + m.FastComm.ToString();
		    foreach (Slave s in m.Slaves) 
            {
			    i = config.Length;
			    Array.Resize(ref config, i + 1);
			    config[i] = "Slave";
			    config[i] += "," + s.SlaveTypeString();
			    foreach (Pin p in s.Pins)
                {
				    i = config.Length;
				    Array.Resize(ref config, i + 1);
				    config[i] = "Pin";
				    config[i] += "," + Pin.PinTypeToString(p.GetPinType());
				    config[i] += "," + p.Slot.ToString();
                    config[i] += "," + p.Value_Max.ToString(ci);
                    config[i] += "," + p.Value_Min.ToString(ci);
                    Int32 nn = p.ResponseSpeed;
                    if (p.AdaptiveSpeed) nn += 1000;
				    config[i] += "," + nn.ToString();
				    switch (p.GetPinType())
                    {
                        case Pin.PinTypes.PWM_8:
                        case Pin.PinTypes.PWM_16:
                            config[i] += "," + p.MaxTime.ToString();
                            config[i] += "," + p.MinTime.ToString();
                            config[i] += "," + p.LogResponse.ToString();
                            break;
					    case Pin.PinTypes.SERVO_8:
					    case Pin.PinTypes.SERVO_16:
						    config[i] += "," + p.MaxTime.ToString();
						    config[i] += "," + p.MinTime.ToString();
						    break;
                        case Pin.PinTypes.STEPPER:
                            config[i] += "," + p.MaxSpeed.ToString(ci);
                            config[i] += "," + p.MaxAcc.ToString(ci);
                            config[i] += "," + p.StepsPerMillimeter.ToString(ci);
                            config[i] += "," + p.LinkedToPrevious.ToString();
                            break;
                        case Pin.PinTypes.PWM_FAST:
                            config[i] += "," + p.PwmFastFrequency.ToString();
                            config[i] += "," + p.PwmFastDutyCycle.ToString();
                            config[i] += "," + p.FrequencyFromSlot.ToString();
                            config[i] += "," + p.DutyCycleFromSlot.ToString();
                            break;
					    case Pin.PinTypes.CAP_8:
					    case Pin.PinTypes.CAP_16:
						    config[i] += "," + p.MinVariation.ToString();
						    config[i] += "," + p.ProportionalArea.ToString();
						    break;
					    case Pin.PinTypes.USOUND_SENSOR:
						    config[i] += "," + p.MaxDist_mm.ToString();
						    config[i] += "," + p.MinDist_mm.ToString();
                            config[i] += "," + p.RemoveErrors.ToString();
						    break;
					    case Pin.PinTypes.CAP_SENSOR:
						    config[i] += "," + p.MaxDist_mm.ToString();
						    config[i] += "," + p.MinDist_mm.ToString();
						    config[i] += "," + p.Area_cmq.ToString();
						    break;
					    case Pin.PinTypes.COUNTER:
					    case Pin.PinTypes.COUNTER_PU:
					    case Pin.PinTypes.FAST_COUNTER:
					    case Pin.PinTypes.FAST_COUNTER_PU:
					    case Pin.PinTypes.PERIOD:
					    case Pin.PinTypes.PERIOD_PU:
                        case Pin.PinTypes.SLOW_PERIOD:
                        case Pin.PinTypes.SLOW_PERIOD_PU:
						    config[i] += "," + p.MaxFreq.ToString();
						    config[i] += "," + p.MinFreq.ToString();
						    config[i] += "," + p.ConvertToFreq.ToString();
						    break;
                        case Pin.PinTypes.ADC_24:
                            config[i] += "," + p.Adc24Npins.ToString();
                            config[i] += "," + p.Adc24Sps.ToString();
                            config[i] += "," + p.Adc24Filter.ToString();
                            break;
                        case Pin.PinTypes.ADC_24_DIN:
                        case Pin.PinTypes.ADC_24_DOUT:
                            break;
                        case Pin.PinTypes.ADC_24_CH:
                        case Pin.PinTypes.ADC_24_CH_B:
                            config[i] += "," + p.Adc24ChType.ToString();
                            config[i] += "," + p.Adc24ChGain.ToString();
                            config[i] += "," + p.Adc24ChBias.ToString();
                            break;
                        case Pin.PinTypes.ENCODER_B:
                        case Pin.PinTypes.ENCODER_B_PU:
                            break;
				    }
			    }
		    }
		    return config;
	    }

	    public static void TheSystem_ValidateConfiguration()
	    {
		    foreach (Master m in Masters)
            {
			    m.ConfigValid = true;
		    }
            ThereminoSystem.ConfigurationIsValid = true;
		    TheSystem_ListComponents();
		    My.MyProject.Forms.Form1.ListView_SetAllLineColors();
            My.MyProject.Forms.Form1.ToolStripButton_Validate.Enabled = !ThereminoSystem.ConfigurationIsValid;
		    My.MyProject.Forms.Form1.EnableCalibrateButton(TheSystem_CalibrationNeeded());
	    }

	    public static void AddToConfigDatabase(string[] config)
	    {
		    if (config.Length > 0) 
            {
			    Int32 count = ConfigDatabase.Length;
			    Array.Resize(ref ConfigDatabase, count + 1);
			    ConfigDatabase[count] = config;
		    }
	    }

	    public static void TheSystem_UpdateAndSaveConfigDatabase()
	    {
		    TheSystem_UpdateConfigDatabase();
		    TheSystem_SaveConfigDatabase();
	    }

	    public static void TheSystem_UpdateConfigDatabase()
	    {
            if (ThereminoSystem.ConfigurationIsValid)
            {
			    foreach (Master m in Masters)
                {
				    if (m.ConfigValid) 
                    {
                        if (m.ConfigId <= ConfigDatabase.Length)
                        {
                            ConfigDatabase[m.ConfigId] = CreateConfig_AsStringArray(m);
                        }
                        else
                        {
                            m.ConfigValid = false;
                            ConfigurationIsValid = false;
                        }   
				    }
			    }
		    }
	    }

	    public static void TheSystem_SaveConfigDatabase()
	    {
            if (ThereminoSystem.ConfigurationIsValid)
            {
			    Module_SaveLoad.Save_ConfigDatabase();
		    }
		    else
            {
			    //MsgBox("Invalid configuration - ""Config Database"" not saved.", MsgBoxStyle.Information)
		    }
	    }

    }
}
