﻿
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;

namespace Theremino_HAL
{
    public partial class Form2 : Form
    {
        Class_DataScope Scope;
        Single VerticalZoom;
        Single ScrollSpeed;

        public Form2()
        {
            LocationChanged += Form2_LocationChanged;
            FormClosing += Form2_FormClosing;
            SizeChanged += Form2_VisibleChanged;
            VisibleChanged += Form2_VisibleChanged;

            Load += Form2_Load;
            InitializeComponent();
        }

        private void Form2_Load(object sender, System.EventArgs e)
        {
            btn_SetZero.ClickButtonArea += btn_SetZero_ClickButtonArea;
            btn_ShowRawCount.ClickButtonArea += btn_ShowRawCount_ClickButtonArea;
            Scope = new Class_DataScope(pbox_ScrollingScope);
            SetScrollSpeed();
            SetUnitsPerDivision();
            SetScaleLabels();
        }

        private void Form2_VisibleChanged(object sender, System.EventArgs e)
        {
            StartTimer();
        }

        private void Form2_Resize(object sender, EventArgs e)
        {
            Scope = new Class_DataScope(pbox_ScrollingScope);
        }

        internal void StopTimer()
        {
            Timer_60Hz.Stop();
        }

        internal void StartTimer()
        {
            if (Visible & WindowState != FormWindowState.Minimized)
            {
                Timer_60Hz.Interval = 15;
                Timer_60Hz.Start();
            }
            else
            {
                Timer_60Hz.Stop();
            }
        }

        private void Form2_FormClosing(object sender, System.Windows.Forms.FormClosingEventArgs e)
        {
            GroupBox1.BackColor = Color.LightGoldenrodYellow;
            this.Hide();
            e.Cancel = true;
        }

        private void Form2_LocationChanged(object sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;

            Module_SaveLoad.LimitFormPosition(this);
        }


        private void Timer_60Hz_Tick(System.Object sender, System.EventArgs e)
        {
            if (!Module_SaveLoad.EventsAreEnabled) return;
            ShowDetails();
            if (btn_Run.Checked) UpdateScrollingScope();
        }

        private Pin SelectedPin;
        private Pin AlternatePin;
        internal Int32 SelectedPinListLine;
        internal Int32 AlternatePinListLine;
       
        internal void RestoreSelectedPins()
        {
            SelectedPin = null;
            AlternatePin = null;
            pbox_ScrollingScope.Visible = true;
            LabelPin1.Text = "- - -";
            lbl_Details1.Text = "";
            Module_FillBars.FillPictureBox(pbox_Details1, 0, Color.Orange, Color.AliceBlue);
            LabelPin2.Text = "- - -";
            lbl_Details2.Text = "";
            Module_FillBars.FillPictureBox(pbox_Details2, 0, Color.Orange, Color.AliceBlue);
            // ------------------------------------------------------ recover selected pins from list lines
            SelectedPin = ThereminoSystem.FindPinByListLine(SelectedPinListLine);
            AlternatePin = ThereminoSystem.FindPinByListLine(AlternatePinListLine);
            InitializePinDetails();
        }

        internal void SetPinDetails()
        {
            Pin p = ThereminoSystem.GetSelectedPin();
            if (p == null) return;
            //
            Int32 l = ThereminoSystem.GetSelectedListLine();
            //
            if (object.ReferenceEquals(p, SelectedPin))
            {
                AlternatePin = null;
                AlternatePinListLine = 0;
                SelectedPin = p;
                SelectedPinListLine = l;
            }
            else
            {
                AlternatePin = SelectedPin;
                AlternatePinListLine = SelectedPinListLine;
                SelectedPin = p;
                SelectedPinListLine = l;
            }
            InitializePinDetails();
        }


        internal void InitializePinDetails()
        {
            if (SelectedPin != null)
            {
                LabelPin1.Text = ComposePinString(SelectedPin);
            }
            if (AlternatePin != null)
            {
                LabelPin2.Text = ComposePinString(AlternatePin);
            }
            else
            {
                LabelPin2.Text = "- - -";
                lbl_Details2.Text = "";
                Module_FillBars.FillPictureBox(pbox_Details2, 0, Color.Orange, Color.AliceBlue);
            }
            //
            // ThereminoSystem.TheSystem_CalibrateZero();
            SetScaleLabels();
        }

        private string ComposePinString(Pin p)
        {
            Int32 npin = p.PinId + 1;
            if (npin <= 12)
            {
                return "M:" + (p.MasterId + 1).ToString() + " S:" + (p.SlaveId + 1).ToString() + " Pin:" + npin.ToString();
            }
            else
            {
                return "M:" + (p.MasterId + 1).ToString() + " Adc24" + " Pin:" + (npin - 12).ToString();
            }
        }

        private Int32 ShowDetailsDivisor;
        private void ShowDetails()
        {
            ShowDetailsDivisor += 1;
            if (ShowDetailsDivisor >= 2) // 2 = 30 executions per second (timer 60Hz divided by 2)
            {
                ShowDetailsDivisor = 0;
                if (SelectedPin != null)
                {
                    lbl_Details1.Text = SelectedPin.GetValueString();
                    Module_FillBars.FillPictureBox(pbox_Details1, SelectedPin.Value_Normalized, Color.Orange, Color.AliceBlue);
                }
                if (AlternatePin != null)
                {
                    lbl_Details2.Text = AlternatePin.GetValueString();
                    Module_FillBars.FillPictureBox(pbox_Details2, AlternatePin.Value_Normalized, Color.Orange, Color.AliceBlue);
                }
            }
        }

        private void btn_SetZero_ClickButtonArea(System.Object Sender, System.EventArgs e)
        {
            ThereminoSystem.TheSystem_CalibrateZero();
            SetScaleLabels();
        }

        private void btn_ShowRawCount_ClickButtonArea(System.Object Sender, System.EventArgs e)
        {
            ThereminoSystem.TheSystem_CalibrateZero();
            SetScaleLabels();
        }

        private void UpdateScrollingScope()
        {
            if (!pbox_ScrollingScope.Visible) return;
            Single v1 = -999;
            Single v2 = -999;
            if (btn_ShowRawCount.Checked)
            {
                if (SelectedPin != null)
                {
                    v1 = (SelectedPin.Value_RawUinteger_Zero - (int)SelectedPin.Value_RawUinteger) * VerticalZoom / 100.0F;
                }
                if (AlternatePin != null)
                {
                    v2 = (AlternatePin.Value_RawUinteger_Zero - (int)AlternatePin.Value_RawUinteger) * VerticalZoom / 100.0F;
                }
            }
            else
            {
                if (cmb_UnitsPerDivision.Text == "Min-Max")
                {
                    if (SelectedPin != null)
                    {
                        v1 = pbox_ScrollingScope.Height * 0.49F * (0.5F - SelectedPin.Value_Normalized);
                    }
                    if (AlternatePin != null)
                    {
                        v2 = pbox_ScrollingScope.Height * 0.49F * (0.5F - AlternatePin.Value_Normalized);
                    }
                 }
                else
                {
                    if (SelectedPin != null)
                    {
                        v1 = pbox_ScrollingScope.Height * 0.49F * (SelectedPin.Value_Zero - SelectedPin.Value) * VerticalZoom / 1000;
                    }
                    if (AlternatePin != null)
                    {
                        v2 = pbox_ScrollingScope.Height * 0.49F * (AlternatePin.Value_Zero - AlternatePin.Value) * VerticalZoom / 1000;
                    }
                }
            }
            Scope.Display(v1, v2, ScrollSpeed);
        }

       
        private System.Globalization.CultureInfo GCI = new System.Globalization.CultureInfo("en-GB");
        private void SetScaleLabels()
        {
            string FS = "0.#";
            switch (cmb_UnitsPerDivision.Text)
            {
                case "0.05":
                case "0.02":
                case "0.01":
                    FS = "0.##";
                    break;
                case "0.005":
                case "0.002":
                case "0.001":
                    FS = "0.###";
                    break;
                case "0.0005":
                case "0.0002":
                case "0.0001":
                    FS = "0.####";
                    break;
            }
            Label_Scale3.Text = "";
            Label_Scale2.Text = "";
            Label_Scale1.Text = "";
            Label_Scale3b.Text = "";
            Label_Scale2b.Text = "";
            Label_Scale1b.Text = "";
            if (btn_ShowRawCount.Checked)
            {
                if (SelectedPin != null)
                {
                    Label_Scale3.Text = (SelectedPin.Value_RawUinteger_Zero + 6800 / VerticalZoom).ToString(FS, GCI);
                    Label_Scale2.Text = SelectedPin.Value_RawUinteger_Zero.ToString(FS, GCI);
                    Label_Scale1.Text = (SelectedPin.Value_RawUinteger_Zero - 6800 / VerticalZoom).ToString(FS, GCI);
               }
               if (AlternatePin != null)
               {
                   Label_Scale3b.Text = (AlternatePin.Value_RawUinteger_Zero + 6800 / VerticalZoom).ToString(FS, GCI);
                   Label_Scale2b.Text = AlternatePin.Value_RawUinteger_Zero.ToString(FS, GCI);
                   Label_Scale1b.Text = (AlternatePin.Value_RawUinteger_Zero - 6800 / VerticalZoom).ToString(FS, GCI);
               }
            }
            else
            {
                if (cmb_UnitsPerDivision.Text == "Min-Max")
                {
                   if (SelectedPin != null)
                   {
                       Label_Scale3.Text = SelectedPin.Value_Max.ToString(FS, GCI);
                       Label_Scale2.Text = ((SelectedPin.Value_Min + SelectedPin.Value_Max) / 2.0F).ToString(FS, GCI);
                       Label_Scale1.Text = SelectedPin.Value_Min.ToString(FS, GCI);
                   }
                   if (AlternatePin != null)
                   {
                       Label_Scale3b.Text = AlternatePin.Value_Max.ToString(FS, GCI);
                       Label_Scale2b.Text = ((AlternatePin.Value_Min + AlternatePin.Value_Max) / 2.0F).ToString(FS, GCI);
                       Label_Scale1b.Text = AlternatePin.Value_Min.ToString(FS, GCI);
                   }
                }
                else
                {
                    if (SelectedPin != null)
                    {
                       float zv = SelectedPin.Value_Zero;
                       Label_Scale3.Text = (zv + 500 / VerticalZoom).ToString(FS, GCI);
                       Label_Scale2.Text = zv.ToString(FS, GCI);
                       Label_Scale1.Text = (zv - 500 / VerticalZoom).ToString(FS, GCI);
                    }
                    if (AlternatePin != null)
                    {
                        float zv = AlternatePin.Value_Zero;
                        Label_Scale3b.Text = (zv + 500 / VerticalZoom).ToString(FS, GCI);
                        Label_Scale2b.Text = zv.ToString(FS, GCI);
                        Label_Scale1b.Text = (zv - 500 / VerticalZoom).ToString(FS, GCI);
                    }
                }
            }
        }

        //  ====================================================================================================
        //    COMBO UnitsPerDivision
        //  ====================================================================================================
        private void cmb_UnitsPerDivision_DropDown(object sender, System.EventArgs e) 
        {
            cmb_UnitsPerDivision.ItemHeight = 16;
        }
        private void cmb_UnitsPerDivision_DropDownClosed(object sender, System.EventArgs e) 
        {
            cmb_UnitsPerDivision.ItemHeight = 12;
        }
        private void cmb_UnitsPerDivision_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetUnitsPerDivision();
        }
        private void SetUnitsPerDivision() 
        {
            VerticalZoom = (float)(Conversion.Val(cmb_UnitsPerDivision.Text) / 100);
            if ((VerticalZoom == 0)) 
            {
                VerticalZoom = 1;
            }
            
            VerticalZoom = (1 / VerticalZoom);
            SetScaleLabels();
        }
        
        //  ====================================================================================================
        //    COMBO ScrollSpeed
        //  ====================================================================================================
        private void cmb_ScrollSpeed_DropDown(object sender, System.EventArgs e) 
        {
            cmb_ScrollSpeed.ItemHeight = 16;
        }
        private void cmb_ScrollSpeed_DropDownClosed(object sender, System.EventArgs e) 
        {
            cmb_ScrollSpeed.ItemHeight = 12;
        }
        private void cmb_ScrollSpeed_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetScrollSpeed();
        }
        private void SetScrollSpeed() 
        {
            ScrollSpeed = (float)(Conversion.Val(cmb_ScrollSpeed.Text));
        }

    }
}
