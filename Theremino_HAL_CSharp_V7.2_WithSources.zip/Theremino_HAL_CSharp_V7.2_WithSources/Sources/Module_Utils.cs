using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace Theremino_HAL
{

	static class Module_Utils
	{
		// ==============================================================================================================
		//   LIST VIEW LINE-INDEX and COLUMN-INDEX FROM CURSOR POSITION
		// ==============================================================================================================

		// --------------------------------------------------------------------------------------------
		//   0 = first line  /  -1 = no line
		// --------------------------------------------------------------------------------------------
		public static Int32 ListView_GetLineIndex(ListView lv)
		{
			Point p = lv.PointToClient(Cursor.Position);
			ListViewItem item = lv.GetItemAt(p.X, p.Y);
			if (item == null) {
				return -1;
			}
			else {
				return item.Index;
			}
		}

		// --------------------------------------------------------------------------------------------
		//   0 = first column  /  -1 = no columns
		// --------------------------------------------------------------------------------------------
		public static Int32 ListView_GetColumnIndex(ListView lv)
		{
			Int32 colx = 0;
			Int32 curx = lv.PointToClient(Cursor.Position).X;
			Int32 index = -1;
			while (index < lv.Columns.Count - 1) 
            {
				index += 1;
				colx += lv.Columns[index].Width;
				if (curx < colx) break;
 
			}
			return index;
		}

		public static void ListView_SelectLine(ListView lv, Int32 line)
		{
			if (line >= 0 & line < lv.Items.Count) 
            {
				lv.Items[line].Selected = true;
			}
		}


		// =======================================================================================
		//  Utils
		// =======================================================================================
		//Friend Function Shell_NormalFocus(ByVal path As String) As Int32
		//    Try
		//        Return Shell(path, AppWinStyle.NormalFocus)
		//    Catch
		//        MsgBox("Cannot open the path: " & vbCr & path, MsgBoxStyle.Information)
		//        Return 0
		//    End Try
		//End Function

		public static string CamelCaseString(string s)
		{
			return Strings.Left(s, 1).ToUpper() + Strings.Mid(s.ToLower(), 2);
		}

        // =======================================================================================
        //  Beep with Repetition Limited
        // =======================================================================================
        private static Stopwatch sw;
        public static void Beep_RepetitionLimited(Int32 ms)
        {
            if (sw == null)
            {
                sw = new Stopwatch();
                sw.Start();
            }
            if (sw.ElapsedMilliseconds < ms) return;
            sw.Reset();
            sw.Start();
            System.Media.SystemSounds.Beep.Play();
        }

		// ==============================================================================================================
		//   COMBO FUNCTIONS
		// ==============================================================================================================
		public static void Combo_Init(ComboBox combo, string str)
		{
            bool old = Module_SaveLoad.EventsAreEnabled;
            Module_SaveLoad.EventsAreEnabled = false;
			if (str == null) str = ""; 
			{
				combo.Items.Clear();
				combo.Items.Add(str);
				combo.SelectedIndex = 0;
			}
            Module_SaveLoad.EventsAreEnabled = old;
		}

		public static void Combo_SetIndex_FromString(ComboBox combo, string str)
		{
            bool old = Module_SaveLoad.EventsAreEnabled;
            Module_SaveLoad.EventsAreEnabled = false;
			if (str == null) str = ""; 
			{
				for (Int32 i = 0; i <= combo.Items.Count - 1; i++) 
                {
					if (combo.Items[i].ToString().Trim() == str) 
                    {
						combo.SelectedIndex = i;
						break;
					}
				}
			}
            Module_SaveLoad.EventsAreEnabled = old;
		}

		public static string Combo_GetValue(ComboBox combo)
		{
			if (combo.SelectedIndex < 0) return ""; 
			return combo.Items[combo.SelectedIndex].ToString();
		}

		public static void Combo_SetIndex(ComboBox combo, Int32 index)
		{
			if (combo.Items.Count < 1) return;
			if (index < 0) index = 0; 
			if (index > combo.Items.Count - 1) index = combo.Items.Count - 1; 
			combo.SelectedIndex = index;
		}


		// =============================================================================================
		//  ASYNC MOUSE KEYS and MOUSE STATE
		// =============================================================================================
		public static bool LeftMousePressed()
		{
            return (Control.MouseButtons & System.Windows.Forms.MouseButtons.Left) != System.Windows.Forms.MouseButtons.None;
		}


		// =============================================================================================
        //  ByteArrays - for STEPPERS 
        //  UINT Destinations are from 0 to 4 gigabytes
        //  The higher value (4 gigabytes - 1) is a special value meaning "reset stepper destination"
		// =============================================================================================
        public static byte[] StepperByteArray_FromUint32(UInt32 n)
        {
            Int64 n2 = n;
            n2 -= 0x80000000U;
            byte[] b = System.BitConverter.GetBytes((Int32)n2);
            if (System.BitConverter.IsLittleEndian) Array.Reverse(b);
            return b;
        }

        // =============================================================================================
        //  ByteArrays 
        // =============================================================================================
        public static byte[] ByteArrayFromUint24(UInt32 n)
        {
            byte[] b = new byte[3];
            b[0] = (byte)((n >> 16) & 255);
            b[1] = (byte)((n >> 8) & 255);
            b[2] = (byte)(n & 255);
            return b;
        }

		public static byte[] ByteArrayFromUint16(UInt16 n)
		{
			byte[] b = new byte[2];
            b[0] = (byte)((n >> 8) & 255);
            b[1] = (byte)(n & 255);
			return b;
		}

        //public static byte[] ByteArray_From_Uint16Array(UInt16[] n)
        //{
        //    byte[] b = new byte[n.Length * 2];
        //    for (Int32 i = 0; i <= n.Length - 1; i++) {
        //        b[i * 2] = (byte)((int)(n[i] / 256));
        //        b[i * 2 + 1] = (byte)(n[i] % 256);
        //    }
        //    return b;
        //}

        // =======================================================================================================
        //   REDIM PRESERVE BIDIMENSIONAL STRING ARRAY
        // =======================================================================================================
        public static void RedimPreserve_2D_Array<T>(ref T[,] original, int rowUpperIdx, int colUpperIdx)
        {
            var newArray = new T[rowUpperIdx + 1, colUpperIdx + 1];
            int minRows = Math.Min(rowUpperIdx + 1, original.GetLength(0));
            int minCols = Math.Min(colUpperIdx + 1, original.GetLength(1));
            for (int i = 0; i < minRows; i++)
                for (int j = 0; j < minCols; j++)
                    newArray[i, j] = original[i, j];
            original = newArray;
        }

        // =========================================================================
        //  LOCK WINDOWS UPDATE
        // ========================================================================= 
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern Int32 LockWindowUpdate(IntPtr hWnd);
        //[System.Runtime.InteropServices.DllImport("User32.dll")]
        //private static extern IntPtr GetDesktopWindow();
        public static void LockFormUpdate(Form frm)
        {
            if (Theremino.OperatingSystemIsWindows) LockWindowUpdate(frm.Handle);
        }
        public static void UnlockFormUpdate()
        {
            if (Theremino.OperatingSystemIsWindows) LockWindowUpdate(IntPtr.Zero);
        }

        // ========================================================
        //   PROCESS START AND WAIT
        // ========================================================
        internal static void ProcessStartAndWait(string fname)
        {
            if (!System.IO.File.Exists(fname)) return;
            Process p = Process.Start(fname);
            do
            {
                System.Threading.Thread.Sleep(100);
            } while (!(p.HasExited));
        }

	}
}
namespace Theremino_HAL
{
	// =============================================================================================
	//  CLASS ReverseIterator
	// =============================================================================================

	internal class ReverseIterator : IEnumerable
	{
		// ------------------------------------------ a low-overhead ArrayList to store references

		ArrayList items = new ArrayList();
		public ReverseIterator(IEnumerable collection)
		{
			// -------------------------------------- load all the items in the ArrayList, but in reverse order
			object o = null;
			foreach (object o_loopVariable in collection) {
				o = o_loopVariable;
				items.Insert(0, o);
			}
		}
		//
		public System.Collections.IEnumerator GetEnumerator()
		{
			// ------------------------------------- return the enumerator of the inner ArrayList
			return items.GetEnumerator();
		}
	}
}


