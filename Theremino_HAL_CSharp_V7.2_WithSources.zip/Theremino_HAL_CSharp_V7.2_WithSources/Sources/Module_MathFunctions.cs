using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;


//using System.Math;
namespace Theremino_HAL
{

	static class Module_MathFunctions
	{

		public static UInt32 AbsUint32Difference(UInt32 n1, UInt32 n2)
		{
			if (n1 > n2) {
				return n1 - n2;
			}
			else {
				return n2 - n1;
			}
		}


		// -------------------------------------------------------------------------------------------
		//  TransferFunction in the range 0 to 1 for both input and output values
		//  Completely simmetric - With Gain and Gamma
		// -------------------------------------------------------------------------------------------
		private static double TransferFunction(double x, double Gain, double Shift, double Slope, double ActivationGain)
		{
			//
			x = 0.5 + (x - 0.5) * Gain;
			//
			x += (Shift - 0.5) * (0.1 * (Slope - 1) + (Gain - 1));
			//
			x = TransferFunction_MidtoneCompress(x, Slope);
			//
			x *= ActivationGain;
			//
			if (x > 1) x = 1; 
			if (x < 0) x = 0; 
			//
			return x;
		}

		// -------------------------------------------------------------------------------------------
		//  Midtone compress in the range 0 to 1 for both input and output values
		//  Completely simmetric and precise
		// -------------------------------------------------------------------------------------------
		private static double TransferFunction_MidtoneCompress(double x, double slope)
		{
			if (slope <= 0) slope = 1E-07; 
			if (x <= 0) x = 1E-07; 
			if (x >= 1) x = 0.9999999; 
			if (x < 0.5) {
				return 0.5 * Math.Exp(-slope * Math.Log(0.5 / x));
			}
			else {
				return 1 - 0.5 * Math.Exp(-slope * Math.Log(0.5 / (1 - x)));
			}
		}

		// ------------------------------------------------------------------------------------------- 
		//   soft saturation ( variable with k ( k = 100 ? ) )
		// -------------------------------------------------------------------------------------------
		private static double TransferFunction_SoftSaturation(double x, double k)
		{
			return 1 / (1 + Math.Pow(k, (1 - 2 * x)));
		}

	}
}
