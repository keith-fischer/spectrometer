using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace Theremino_HAL
{
	static class Module_ElectronicFormula
	{

		// --------------------------------------------------------------------------------------- CAPACITORS
		//                       1     
		// CapSerial = ------------------------          S = 1/(1/a + 1/b)
		//                  1            1  
		//              --------- + ---------- 
		//                 Cap1        Cap2

		//              Cap1 * CapSerial  
		//     Cap2 = ------------------                 b = a · S / (a - S)   
		//              Cap1 - CapSerial

		public static double ELEC_Cserial(double Cap1, double Cap2)
		{
			return 1 / (1 / Cap1 + 1 / Cap2);
		}
		public static double ELEC_C2_FromSerial(double Cserial, double C1)
		{
			return (C1 * Cserial) / (C1 - Cserial);
		}

		// --------------------------------------------------------------------------------------- INDUCTORS
		public static double ELEC_Lserial(double L1, double L2)
		{
			return 1 / (1 / L1 + 1 / L2);
		}
		public static double ELEC_L2_from_Lserial(double L_serial, double L1)
		{
			return (L1 * L_serial) / (L1 - L_serial);
		}

		// --------------------------------------------------------------------------------------- RESISTORS
		public static double ELEC_Rparallel(double R1, double R2)
		{
			return 1 / (1 / R1 + 1 / R2);
		}
		public static double ELEC_R2_FromParallel(double Rparallel, double R1)
		{
			return (R1 * Rparallel) / (R1 - Rparallel);
		}

	}
}
