using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

using System.Runtime.InteropServices;
namespace Theremino_HAL
{

	// Althought ReadFile and WriteFile parameters are all pinned 
	// ------------------------------------------------------------------------------------------
	// - there is one slave-servo with some active pin: servo_16 / Adc_16 ...  
	// - rep time 66
	// - speed 2
	// - try with the component-details window visible or not visible
	// - the program is compiled with: Project-properties / Advanced / Generate-debug-info = NONE
	//
	// Open the program and immediately traverse the listbox up and down 
	//  with keyboard up/down arrows about 5 to 10 times and the program crashes
	// ------------------------------------------------------------------------------------------

	// SOLUTION >>>> SET: Project-properties / "Release" / Advanced / Generate-debug-info = Full


	// Overlapped I/O
	// =====================================================================================
	// Reading HID Input reports is done with the API function ReadFile.
	//
	// Non-overlapped ReadFile is a blocking call. If the device doesn't return the
	// expected amount of data, the application hangs and waits endlessly.
	//
	// With overlapped I/O, the call to ReadFile returns immediately.
	// The application uses WaitForSingleObject to be notified either that
	// the data has arrived or that a timeout has occurred.
	//
	// WaitForSingleObject blocks the application thread but specifies a timeout value
	// so the application's thread isn't blocked forever.
	// ======================================================================================


	// #################################################################################################
	//  PARTIAL THEREMINO_HID CLASS
	// #################################################################################################
	public partial class Theremino_HID
	{

		// ======================================================================================
		//   CONSTANTS
		// ======================================================================================

		private const int DIGCF_PRESENT = 0x2;
		private const int DIGCF_DEVICEINTERFACE = 0x10;
		private const int FILE_FLAG_OVERLAPPED = 0x40000000;
		private const int FILE_SHARE_READ = 0x1;
		private const int FILE_SHARE_WRITE = 0x2;
		private const int FORMAT_MESSAGE_FROM_SYSTEM = 0x1000;
		private const uint GENERIC_READ = 0x80000000;
        //const int GENERIC_READ = 0x80000000;

		private const int GENERIC_WRITE = 0x40000000;
		// ------------------------------ if possible declare as integers (16 bits)
		private const short HidP_Input = 0;
		private const short HidP_Output = 1;

		private const short HidP_Feature = 2;
		private const short OPEN_EXISTING = 3;
		private const int WAIT_TIMEOUT = 0x102;

		private const short WAIT_OBJECT_0 = 0;

		// ======================================================================================
		//   TYPES
		// ======================================================================================
		[StructLayout(LayoutKind.Sequential)]
		private struct HIDD_ATTRIBUTES
		{
			public int Size;
			public short VendorID;
			public short ProductID;
			public short VersionNumber;
		}

		[StructLayout(LayoutKind.Sequential)]
		private struct HIDP_CAPS
		{
			public short Usage;
			public short UsagePage;
			public short InputReportByteLength;
			public short OutputReportByteLength;
			public short FeatureReportByteLength;
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 17)]
			public short[] Reserved;
			public short NumberLinkCollectionNodes;
			public short NumberInputButtonCaps;
			public short NumberInputValueCaps;
			public short NumberInputDataIndices;
			public short NumberOutputButtonCaps;
			public short NumberOutputValueCaps;
			public short NumberOutputDataIndices;
			public short NumberFeatureButtonCaps;
			public short NumberFeatureValueCaps;
			public short NumberFeatureDataIndices;
		}

		//If IsRange is false, UsageMin is the Usage and UsageMax is unused.
		//If IsStringRange is false, StringMin is the string index and StringMax is unused.
		//If IsDesignatorRange is false, DesignatorMin is the designator index and DesignatorMax is unused.

		[StructLayout(LayoutKind.Sequential)]
		private struct HidP_Value_Caps
		{
			public short UsagePage;
			public byte ReportID;
			public int IsAlias;
			public short BitField;
			public short LinkCollection;
			public short LinkUsage;
			public short LinkUsagePage;
			public int IsRange;
			public int IsStringRange;
			public int IsDesignatorRange;
			public int IsAbsolute;
			public int HasNull;
			public byte Reserved;
			public short BitSize;
			public short ReportCount;
			public short Reserved2;
			public short Reserved3;
			public short Reserved4;
			public short Reserved5;
			public short Reserved6;
			public int LogicalMin;
			public int LogicalMax;
			public int PhysicalMin;
			public int PhysicalMax;
			public short UsageMin;
			public short UsageMax;
			public short StringMin;
			public short StringMax;
			public short DesignatorMin;
			public short DesignatorMax;
			public short DataIndexMin;
			public short DataIndexMax;
		}

		[StructLayout(LayoutKind.Sequential)]
		private struct OVERLAPPED
		{
			public int Internal;
			public int InternalHigh;
			public int Offset;
			public int OffsetHigh;
			public int hEvent;
		}

		[StructLayout(LayoutKind.Sequential)]
		private struct SECURITY_ATTRIBUTES
		{
			public int nLength;
			public int lpSecurityDescriptor;
			public bool bInheritHandle;
		}


		// There are two declarations for the DEV_BROADCAST_DEVICEINTERFACE structure.
		//
		// Use this in the call to RegisterDeviceNotification() and
		// in checking dbch_devicetype in a DEV_BROADCAST_HDR structure.
		[StructLayout(LayoutKind.Sequential)]
		private class DEV_BROADCAST_DEVICEINTERFACE
		{
			public int dbcc_size;
			public int dbcc_devicetype;
			public int dbcc_reserved;
			public Guid dbcc_classguid;
			public short dbcc_name;
		}

		// Use this to read the dbcc_name string and classguid.
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		private class DEV_BROADCAST_DEVICEINTERFACE_1
		{
			public int dbcc_size;
			public int dbcc_devicetype;
			public int dbcc_reserved;
			[MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.U1, SizeConst = 16)]
			public byte[] dbcc_classguid;
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 255)]
			public char[] dbcc_name;
		}

		[StructLayout(LayoutKind.Sequential)]
		private class DEV_BROADCAST_HANDLE
		{
			public int dbch_size;
			public int dbch_devicetype;
			public int dbch_reserved;
			public int dbch_handle;
			public int dbch_hdevnotify;
		}

		[StructLayout(LayoutKind.Sequential)]
		private class DEV_BROADCAST_HDR
		{
			public int dbch_size;
			public int dbch_devicetype;
			public int dbch_reserved;
		}

		[StructLayout(LayoutKind.Sequential)]
		private struct SP_DEVICE_INTERFACE_DATA
		{
			public int cbSize;
			public System.Guid InterfaceClassGuid;
			public int Flags;
				//Integer    ' TODO IntPtr is best for 64 bit ??????????????
			public IntPtr Reserved;
		}

		[StructLayout(LayoutKind.Sequential)]
		private struct SP_DEVICE_INTERFACE_DETAIL_DATA
		{
			public int cbSize;
			public string DevicePath;
		}

		[StructLayout(LayoutKind.Sequential)]
		private struct SP_DEVINFO_DATA
		{
			public int cbSize;
			public System.Guid ClassGuid;
			public int DevInst;
			public int Reserved;
		}


		// ======================================================================================
		//   API FUNCTIONS
		// ======================================================================================
		[DllImport("hid.dll")]
		private static extern bool HidD_FlushQueue(int HidDeviceObject);

		[DllImport("hid.dll")]
		private static extern bool HidD_GetFeature(int HidDeviceObject, ref byte lpReportBuffer, int ReportBufferLength);

		[DllImport("hid.dll")]
		private static extern bool HidD_GetInputReport(int HidDeviceObject, ref byte lpReportBuffer, int ReportBufferLength);

		[DllImport("hid.dll")]
		private static extern void HidD_GetHidGuid(ref System.Guid HidGuid);

		[DllImport("hid.dll")]
		private static extern bool HidD_GetNumInputBuffers(int HidDeviceObject, ref int NumberBuffers);

		[DllImport("hid.dll")]
		private static extern bool HidD_SetFeature(int HidDeviceObject, ref byte lpReportBuffer, int ReportBufferLength);

		[DllImport("hid.dll")]
		private static extern bool HidD_SetNumInputBuffers(int HidDeviceObject, int NumberBuffers);

		[DllImport("hid.dll")]
		private static extern bool HidD_SetOutputReport(int HidDeviceObject, ref byte lpReportBuffer, int ReportBufferLength);

		[DllImport("hid.dll")]
		private static extern int HidP_GetCaps(IntPtr PreparsedData, ref HIDP_CAPS Capabilities);

		[DllImport("hid.dll")]
		private static extern int HidP_GetValueCaps(short ReportType, ref byte ValueCaps, ref short ValueCapsLength, IntPtr PreparsedData);

		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		private static extern int CreateEvent(ref SECURITY_ATTRIBUTES SecurityAttributes, bool bManualReset, bool bInitialState, string lpName);

		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		private static extern Int32 CreateFile(string lpFileName, uint dwDesiredAccess, int dwShareMode, ref SECURITY_ATTRIBUTES lpSecurityAttributes, int dwCreationDisposition, int dwFlagsAndAttributes, int hTemplateFile);

		[DllImport("kernel32.dll")]
		private static extern bool CloseHandle(Int32 hObject);

		[DllImport("hid.dll")]
		private static extern bool HidD_GetPreparsedData(Int32 HidDeviceObject, ref IntPtr PreparsedData);

		[DllImport("hid.dll")]
		private static extern bool HidD_FreePreparsedData(ref IntPtr PreparsedData);

		[DllImport("hid.dll")]
		private static extern bool HidD_GetAttributes(Int32 HidDeviceObject, ref HIDD_ATTRIBUTES Attributes);

		[DllImport("kernel32.dll")]
		private static extern bool CancelIo(Int32 hFile);

		[DllImport("kernel32.dll")]
		private static extern bool ReadFile(Int32 hFile, ref byte lpBuffer, int nNumberOfBytesToRead, ref int lpNumberOfBytesRead, ref OVERLAPPED lpOverlapped);

		[DllImport("kernel32.dll")]
		private static extern int WaitForSingleObject(int hHandle, int dwMilliseconds);

		[DllImport("kernel32.dll")]
		private static extern bool WriteFile(Int32 hFile, ref byte lpBuffer, int nNumberOfBytesToWrite, ref int lpNumberOfBytesWritten, int lpOverlapped);

		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		private static extern IntPtr RegisterDeviceNotification(IntPtr hRecipient, IntPtr NotificationFilter, Int32 Flags);

		[DllImport("setupapi.dll")]
		private static extern int SetupDiCreateDeviceInfoList(ref System.Guid ClassGuid, int hwndParent);

		[DllImport("setupapi.dll")]
		private static extern int SetupDiDestroyDeviceInfoList(IntPtr DeviceInfoSet);

		[DllImport("setupapi.dll")]
		private static extern bool SetupDiEnumDeviceInterfaces(IntPtr DeviceInfoSet, int DeviceInfoData, ref System.Guid InterfaceClassGuid, int MemberIndex, ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData);

		[DllImport("setupapi.dll", CharSet = CharSet.Auto)]
		private static extern IntPtr SetupDiGetClassDevs(ref System.Guid ClassGuid, string Enumerator, int hwndParent, int Flags);

		[DllImport("setupapi.dll", CharSet = CharSet.Auto)]
		private static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr DeviceInfoSet, ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData, IntPtr DeviceInterfaceDetailData, int DeviceInterfaceDetailDataSize, ref int RequiredSize, IntPtr DeviceInfoData);

		[DllImport("user32.dll")]
		private static extern bool UnregisterDeviceNotification(IntPtr Handle);


		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		private static extern int FormatMessage(int dwFlags, ref long lpSource, int dwMessageId, int dwLanguageZId, string lpBuffer, int nSize, int Arguments);



		// =================================================================================================
		//  PRIVATE DATA
		// =================================================================================================
		public bool MyDeviceDetected;
		private short USB_Timeout;
		private bool DisplayResults = false;
		private HIDP_CAPS Capabilities;
		private HIDD_ATTRIBUTES DeviceAttributes;
		private string DevicePathName;
		private int EventObject;
		private Int32 HIDHandle;
		private Int32 ReadHandle;
		private OVERLAPPED HIDOverlapped;
		private SECURITY_ATTRIBUTES Security;
		private SP_DEVICE_INTERFACE_DETAIL_DATA MyDeviceInterfaceDetailData;
		private SP_DEVICE_INTERFACE_DATA MyDeviceInterfaceData;
		private IntPtr PreparsedData;

		// =================================================================================================
		//  PRIVATE FUNCTIONS  -  READ REPORT and WRITE REPORT
		// =================================================================================================
		private bool ReadReport()
		{
			bool functionReturnValue = false;
			bool bResult = false;
			Int32 iResult = default(Int32);
			functionReturnValue = false;

			// -------------------------------------------- Read data from the device.
			int NumberOfBytesRead = 0;
			// -------------------------------------------- Allocate a buffer for the report.
			// -------------------------------------------- Byte 0 is the report ID
			// -------------------------------------------- and the ReadBuffer array begins at 0,
			// -------------------------------------------- so subtract 1 from the number of bytes.
			byte[] ReadBuffer = new byte[Capabilities.InputReportByteLength];

			// -------------------------------------------- byref objects are to be pinned
			GCHandle pinnedReadBuffer = default(GCHandle);
			pinnedReadBuffer = GCHandle.Alloc(ReadBuffer, GCHandleType.Pinned);
			GCHandle pinnedOverlappedStructure = default(GCHandle);
			pinnedOverlappedStructure = GCHandle.Alloc(HIDOverlapped, GCHandleType.Pinned);
			GCHandle pinnedNumberOfBytesRead = default(GCHandle);
			pinnedNumberOfBytesRead = GCHandle.Alloc(NumberOfBytesRead, GCHandleType.Pinned);

			//******************************************************************************
			// ReadFile
			// Returns: the report in ReadBuffer.
			// Requires: a device handle returned by CreateFile
			// (for overlapped I/O, CreateFile must be called with FILE_FLAG_OVERLAPPED),
			// the Input report length in bytes returned by HidP_GetCaps,
			// and an overlapped structure whose hEvent member is set to an event object.
			// http://msdn.microsoft.com/en-us/library/aa365467(v=vs.85).aspx
			//******************************************************************************
			// -------------------------------------------- Do an overlapped ReadFile.
			// -------------------------------------------- The function returns immediately,
			// -------------------------------------------- even if the data hasn't been received yet.
			bResult = Theremino_HAL.Theremino_HID.ReadFile(ReadHandle, 
                                                           ref ReadBuffer[0], 
                                                           Capabilities.InputReportByteLength, 
                                                           ref NumberOfBytesRead, 
                                                           ref HIDOverlapped);


			if (DisplayResults) 
            {
				Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("ReadFile");
				Theremino_HAL.Theremino_HID.DisplayResult("waiting for ReadFile");
			}

			//******************************************************************************
			// WaitForSingleObject
			// Used with overlapped ReadFile.
			// Returns when ReadFile has received the requested amount of data or on timeout.
			// Requires an event object created with CreateEvent
			// and a timeout value in milliseconds.
			//******************************************************************************
			iResult = Theremino_HAL.Theremino_HID.WaitForSingleObject(EventObject, USB_Timeout);
			if (DisplayResults) Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("WaitForSingleObject"); 


			// -------------------------------------------------------------- find out if ReadFile completed or timeout
			switch (iResult) 
            {

				case Theremino_HAL.Theremino_HID.WAIT_OBJECT_0:
					// ------------------------------------------------------ readFile is completed
					if (DisplayResults) Theremino_HAL.Theremino_HID.DisplayResult("ReadFile completed successfully."); 

					// ------------------------------------------------------ copy data to USB_RxData()
					for (Int32 Count = 1; Count < ReadBuffer.Length; Count++) {
						USB_RxData[Count - 1] = ReadBuffer[Count];
					}

					functionReturnValue = true;

					break;

				case Theremino_HAL.Theremino_HID.WAIT_TIMEOUT:
					// ------------------------------------------------------ cancel the operation
					bResult = Theremino_HAL.Theremino_HID.CancelIo(ReadHandle);
					if (DisplayResults) {
						Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("CancelIo");
						Theremino_HAL.Theremino_HID.DisplayResult("************ReadFile timeout*************");
					}

					// ------------------------------------ The timeout may have been because the device was removed,
					// ------------------------------------ so close any open handles and
					// ------------------------------------ set MyDeviceDetected=False to cause the application to
					// ------------------------------------ look for the device on the next attempt.
					Theremino_HAL.Theremino_HID.CloseHandle(HIDHandle);
					if (DisplayResults) Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("CloseHandle (HIDHandle)"); 
					Theremino_HAL.Theremino_HID.CloseHandle(ReadHandle);
					if (DisplayResults) Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("CloseHandle (ReadHandle)"); 
					MyDeviceDetected = false;

					break;
                    //Module_Utils.Beep_RepetitionLimited(150);
				    //Debug.Print("timeout")

				default:

                    //Module_Utils.Beep_RepetitionLimited(150);
					//Debug.Print("undefined")

					if (DisplayResults) Theremino_HAL.Theremino_HID.DisplayResult("Readfile undefined error"); 
					MyDeviceDetected = false;

					break;
			}

			if (DisplayResults) 
            {
				Theremino_HAL.Theremino_HID.DisplayResult(" Report ID: " + ReadBuffer[0]);
				Theremino_HAL.Theremino_HID.DisplayResult(" Report Data:");
				for (Int32 Count = 1; Count < ReadBuffer.Length; Count++) 
                {
					Theremino_HAL.Theremino_HID.DisplayResult(" " + Conversion.Hex(ReadBuffer[Count]));
				}
			}

			// -------------------------------------------- release the pinned objects
			pinnedReadBuffer.Free();
			pinnedOverlappedStructure.Free();
			pinnedNumberOfBytesRead.Free();
			return functionReturnValue;

		}

		private void WriteReport()
		{
			bool bResult = false;

			// -------------------------------------------- Send data to the device.
			Int32 Count = default(Int32);
			int NumberOfBytesWritten = 0;

			// -------------------------------------------- The SendBuffer array begins at 0,
			// -------------------------------------------- so subtract 1 from the number of bytes.
			byte[] SendBuffer = new byte[Capabilities.OutputReportByteLength];

			// -------------------------------------------- The first byte is the Report ID
			SendBuffer[0] = 0;
			// -------------------------------------------- The next bytes are data
			for (Count = 1; Count < SendBuffer.Length; Count++) 
            {
                SendBuffer[Count] = USB_TxData[Count - 1];
			}

			// --------------------------------------------  byref objects are to be pinned
			GCHandle pinnedSendBuffer = default(GCHandle);
			pinnedSendBuffer = GCHandle.Alloc(SendBuffer, GCHandleType.Pinned);
			GCHandle pinnedNumberOfBytesWritten = default(GCHandle);
			pinnedNumberOfBytesWritten = GCHandle.Alloc(NumberOfBytesWritten, GCHandleType.Pinned);

			//******************************************************************************
			//WriteFile
			//Sends a report to the device.
			//Returns: success or failure.
			//Requires: the handle returned by CreateFile and
			//The output report byte length returned by HidP_GetCaps
			//******************************************************************************
			bResult = Theremino_HAL.Theremino_HID.WriteFile(HIDHandle, ref SendBuffer[0], Capabilities.OutputReportByteLength, ref NumberOfBytesWritten, 0);

			// -------------------------------------------- release the pinned objects
			pinnedSendBuffer.Free();
			pinnedNumberOfBytesWritten.Free();

			if (DisplayResults) 
            {
				Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("WriteFile");
				Theremino_HAL.Theremino_HID.DisplayResult(" OutputReportByteLength = " + Capabilities.OutputReportByteLength);
				Theremino_HAL.Theremino_HID.DisplayResult(" NumberOfBytesWritten = " + NumberOfBytesWritten);
				Theremino_HAL.Theremino_HID.DisplayResult(" Report ID: " + SendBuffer[0]);
				Theremino_HAL.Theremino_HID.DisplayResult(" Report Data:");
                for (Count = 1; Count < SendBuffer.Length; Count++)
                {
					Theremino_HAL.Theremino_HID.DisplayResult(" " + Conversion.Hex(SendBuffer[Count]));
				}
			}

		}

		private void PrepareForOverlappedTransfer()
		{
			//******************************************************************************
			//CreateEvent
			//Creates an event object for the overlapped structure used with ReadFile.
			//Requires a security attributes structure or null,
			//Manual Reset = True (ResetEvent resets the manual reset object to nonsignaled),
			//Initial state = True (signaled),
			//and event object name (optional)
			//Returns a handle to the event object.
			//******************************************************************************
			if (EventObject == 0) {
				EventObject = Theremino_HAL.Theremino_HID.CreateEvent(ref Security, false, true, "");
			}
			if (DisplayResults) Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("CreateEvent"); 
			// -------------------------------------------- Set the members of the overlapped structure.
			HIDOverlapped.Offset = 0;
			HIDOverlapped.OffsetHigh = 0;
			HIDOverlapped.hEvent = EventObject;
		}

		private void GetDeviceCapabilities()
		{
			bool bResult = false;
			Int32 iResult = default(Int32);

			//******************************************************************************
			//HidD_GetPreparsedData
			//Returns: a pointer to a buffer containing information about the device's capabilities.
			//Requires: A handle returned by CreateFile.
			//There's no need to access the buffer directly,
			//but HidP_GetCaps and other API functions require a pointer to the buffer.
			//******************************************************************************

			// -------------------------------------------- Preparsed Data is a pointer to a routine-allocated buffer.
			bResult = Theremino_HAL.Theremino_HID.HidD_GetPreparsedData(HIDHandle, ref PreparsedData);
			if (DisplayResults) Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("HidD_GetPreparsedData"); 

			//******************************************************************************
			//HidP_GetCaps
			//Find out the device's capabilities.
			//For standard devices such as joysticks, you can find out the specific
			//capabilities of the device.
			//For a custom device, the software will probably know what the device is capable of,
			//so this call only verifies the information.
			//Requires: The pointer to a buffer containing the information.
			//The pointer is returned by HidD_GetPreparsedData.
			//Returns: a Capabilites structure containing the information.
			//******************************************************************************
			iResult = Theremino_HAL.Theremino_HID.HidP_GetCaps(PreparsedData, ref Capabilities);

			if (DisplayResults) {
				byte[] ppData = new byte[30];
				object ppDataString = null;
				ppDataString = System.Convert.ToBase64String(ppData);
				//
				Theremino_HAL.Theremino_HID.DisplayResult("  Usage: " + Conversion.Hex(Capabilities.Usage));
				Theremino_HAL.Theremino_HID.DisplayResult("  Usage Page: " + Conversion.Hex(Capabilities.UsagePage));
				Theremino_HAL.Theremino_HID.DisplayResult("  Input Report Byte Length: " + Capabilities.InputReportByteLength);
				Theremino_HAL.Theremino_HID.DisplayResult("  Output Report Byte Length: " + Capabilities.OutputReportByteLength);
				Theremino_HAL.Theremino_HID.DisplayResult("  Feature Report Byte Length: " + Capabilities.FeatureReportByteLength);
				Theremino_HAL.Theremino_HID.DisplayResult("  Number of Link Collection Nodes: " + Capabilities.NumberLinkCollectionNodes);
				Theremino_HAL.Theremino_HID.DisplayResult("  Number of Input Button Caps: " + Capabilities.NumberInputButtonCaps);
				Theremino_HAL.Theremino_HID.DisplayResult("  Number of Input Value Caps: " + Capabilities.NumberInputValueCaps);
				Theremino_HAL.Theremino_HID.DisplayResult("  Number of Input Data Indices: " + Capabilities.NumberInputDataIndices);
				Theremino_HAL.Theremino_HID.DisplayResult("  Number of Output Button Caps: " + Capabilities.NumberOutputButtonCaps);
				Theremino_HAL.Theremino_HID.DisplayResult("  Number of Output Value Caps: " + Capabilities.NumberOutputValueCaps);
				Theremino_HAL.Theremino_HID.DisplayResult("  Number of Output Data Indices: " + Capabilities.NumberOutputDataIndices);
				Theremino_HAL.Theremino_HID.DisplayResult("  Number of Feature Button Caps: " + Capabilities.NumberFeatureButtonCaps);
				Theremino_HAL.Theremino_HID.DisplayResult("  Number of Feature Value Caps: " + Capabilities.NumberFeatureValueCaps);
				Theremino_HAL.Theremino_HID.DisplayResult("  Number of Feature Data Indices: " + Capabilities.NumberFeatureDataIndices);

				// ---------------------------------------------------------------------------------------
				// HidP_GetValueCaps
				// Returns a buffer containing an array of HidP_ValueCaps structures.
				// Each structure defines the capabilities of one value.
				// This application doesn't use this data.
				//
				// -------------------------------------------- This is a guess. The byte array holds the structures.
				byte[] ValueCaps = new byte[1024];
				iResult = Theremino_HAL.Theremino_HID.HidP_GetValueCaps(Theremino_HAL.Theremino_HID.HidP_Input, ref ValueCaps[0], ref Capabilities.NumberInputValueCaps, PreparsedData);
				Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("HidP_GetValueCaps");
				//lstResults.AddItem "ValueCaps= " & GetDataString((VarPtr(ValueCaps(0))), 180)
				// --------------------------------------------  To use this data, copy the byte array into an array of structures
			}

			// ------------------------------------------------ Free the buffer reserved by HidD_GetPreparsedData
			bResult = Theremino_HAL.Theremino_HID.HidD_FreePreparsedData(ref PreparsedData);
			if (DisplayResults) Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("HidD_FreePreparsedData"); 
		}



		// #################################################################################################
		//  PRIVATE - DISPLAY RESULTS FUNCTIONS
		// #################################################################################################
		private static TextBox USB_Results = null;
		private static string GetErrorString(int LastError)
		{
			string functionReturnValue = null;
			// ---------------------------------------- Returns the error message for the last error.
            long dummy = 0;
			int Bytes = 0;
			string ErrorString = null;
			ErrorString = new string(Strings.Chr(0), 129);
			Bytes = Theremino_HID.FormatMessage(Theremino_HID.FORMAT_MESSAGE_FROM_SYSTEM, ref dummy, LastError, 0, ErrorString, 128, 0);
			// ---------------------------------------- Subtract two characters from the message to strip the CR and LF.
			if (Bytes > 2) 
            {
				functionReturnValue = Strings.Left(ErrorString, Bytes - 2);
			}
			else 
            {
				functionReturnValue = "";
			}
			return functionReturnValue;
		}

		private static void DisplayResultOfAPICall(string FunctionName)
		{
			string ErrorString = null;
			if ((Theremino_HAL.Theremino_HID.USB_Results != null)) 
            {
				// -------------------------------------------- Avoid problems with very long lists
				if (Theremino_HAL.Theremino_HID.USB_Results.Text.Length > 32000) Theremino_HAL.Theremino_HID.USB_Results.Clear(); 
				// -------------------------------------------- Display the results of an API call.
				Theremino_HAL.Theremino_HID.USB_Results.Text += Constants.vbCrLf;
                ErrorString = Theremino_HAL.Theremino_HID.GetErrorString(Microsoft.VisualBasic.Information.Err().LastDllError);
				Theremino_HAL.Theremino_HID.USB_Results.Text += FunctionName + Constants.vbCrLf;
				if (ErrorString != "Memoria insufficiente per eseguire il comando.") 
                {
					Theremino_HAL.Theremino_HID.USB_Results.Text += "  Result = " + ErrorString + Constants.vbCrLf;
				}
				// -------------------------------------------- Scroll to the bottom of the list box.
				//USB_Results.SelectedIndex = USB_Results.Items.Count - 1
			}
		}

		private static void DisplayResult(string Result)
		{
			if ((Theremino_HAL.Theremino_HID.USB_Results != null)) 
            {
				// -------------------------------------------- Avoid problems with very long lists
				if (Theremino_HAL.Theremino_HID.USB_Results.Text.Length > 32000) Theremino_HAL.Theremino_HID.USB_Results.Clear(); 
				// -------------------------------------------- Display the results
				Theremino_HAL.Theremino_HID.USB_Results.Text += Result + Constants.vbCrLf;
				// -------------------------------------------- Scroll to the bottom of the list box.
				//USB_Results.SelectedIndex = USB_Results.Items.Count - 1
			}
		}

		private static void DisplayGUID(ref Guid g)
		{
			if ((Theremino_HAL.Theremino_HID.USB_Results != null)) 
            {
				Theremino_HAL.Theremino_HID.DisplayResult("  GUID for system HIDs: " + g.ToString());
			}
		}



		// =================================================================================================
		//  PUBLIC FUNCTIONS
		// =================================================================================================
		public byte[] USB_TxData = new byte[8193];

        public byte[] USB_RxData = new byte[8193];

        public Theremino_HID()
		{
			USB_Timeout = 2000;
            if (!Theremino.OperatingSystemIsWindows)
            {
				New_Unix();
			}
		}

        ~Theremino_HID()
		{
			bool bResult = false;
			// -------------------------------------------- Actions that must execute when the program ends.
			// -------------------------------------------- Close the open handles to the device.
			bResult = Theremino_HAL.Theremino_HID.CloseHandle(HIDHandle);
			if (DisplayResults) Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("CloseHandle (HIDHandle)"); 
			// --------------------------------------------
			bResult = Theremino_HAL.Theremino_HID.CloseHandle(ReadHandle);
			if (DisplayResults) Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("CloseHandle (ReadHandle)"); 
			//
            Finalize_Unix();
		}

		internal void USB_Write_Read()
		{
			// ------------------------------------------------ do not charge the cpu if not detected
			if (!MyDeviceDetected) 
            {
                System.Threading.Thread.Sleep(10);
				return;
			}
			// ------------------------------------------------ do the exchange
            if (Theremino.OperatingSystemIsWindows)
            {
				WriteReport();
				ReadReport();
			}
			else 
            {
				WriteReport_Unix();
				ReadReport_Unix();
			}
		}


		// -----------------------------------------------------------------------------------------------------------
		//  GetUsbDeviceString is used to disable/enable the usb to master communication
		// ----------------------------------------------------------------------------------------------------------- 
		//    "USB\ROOT_HUB&VID1002&PID438A" <<< HUB
		// 
		//    "USB\Vid_04d8&Pid_3eff"        <<< HID
		//
		//    DevicePathName = "\\?\hid#vid_04d8&pid_3eff#6&26f3c096&1&0000#{4d1e55b2-f16f-11cf-88cb-001111000030}"
		// -----------------------------------------------------------------------------------------------------------
		//Friend Function GetUsbDeviceString() As String
		//    Dim s As String
		//    s = DevicePathName
		//    Debug.Print(s)
		//    Return s
		//End Function


		// =====================================================================================
		//  All the USB operations can be accessed using the following data and functions
		// =====================================================================================
		// USB_VendorID                  integer value (16bit)
		// USB_ProductID                 integer value (16bit)
		// USB_Timeout                   timeout (in mS) (if data are not received)
		// USB_TxData(xxx)               Byte array with the output-data ( length is determined in the firmware )
		// USB_RxData(xxx)               Byte array with the input-data ( length is determined in the firmware )
		// USB_Results                   a ListBox useful to debug return values
		// USB_ReadWrite()               call this function to perform the data exchange

		// =====================================================================================
		// USB_VendorID and USB_ProductID must match the device's firmware values
		// 0925 = Lakeview Research's
		// 04D8 = Microchip
		// =====================================================================================


		// #################################################################################################
		//  FIND and INITIALIZE THEREMINO HIDS
		// #################################################################################################
		public static void FindThereminoHids(bool Reconnect)
		{
			const short USB_VendorID = 0x4d8;
			// VendorID  = Microchip
			const short USB_ProductID = 0x3eff;
			// ProductID = Theremino

			bool LastDevice = false;
			bool bResult = false;
			Int32 iResult = default(Int32);
			IntPtr DeviceInfoSet = default(IntPtr);

			//******************************************************************************
			// HidD_GetHidGuid
			// Get the GUID for all system HIDs.
			// Returns: the GUID in HidGuid.
			// The routine doesn't return a value in Result
			// but the routine is declared as a function for consistency with the other API calls.
			//******************************************************************************
			System.Guid HidGuid = default(System.Guid);
			HidGuid = System.Guid.Empty;
			Theremino_HAL.Theremino_HID.HidD_GetHidGuid(ref HidGuid);
			Theremino_HAL.Theremino_HID.DisplayGUID(ref HidGuid);

			//******************************************************************************
			// SetupDiGetClassDevs
			// Returns: a handle to a device information set for all installed devices.
			// Requires: the HidGuid returned in GetHidGuid.
			//******************************************************************************
			DeviceInfoSet = Theremino_HAL.Theremino_HID.SetupDiGetClassDevs(ref HidGuid, Constants.vbNullString, 0, Theremino_HAL.Theremino_HID.DIGCF_PRESENT | Theremino_HAL.Theremino_HID.DIGCF_DEVICEINTERFACE);

			Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("SetupDiClassDevs");

			//******************************************************************************
			// SetupDiEnumDeviceInterfaces
			// On return, MyDeviceInterfaceData contains the handle to a
			// SP_DEVICE_INTERFACE_DATA structure for a detected device.
			// Requires:
			// the DeviceInfoSet returned in SetupDiGetClassDevs.
			// the HidGuid returned in GetHidGuid.
			// An index to specify a device.
			//******************************************************************************

			// ------------------------------------------- Begin with 0 and increment until no more devices are detected.
			int MemberIndex = default(Int32);
			MemberIndex = 0;
			LastDevice = false;

			// ------------------------------------------- 
			Int32 masterID = 0;
			Master _master = null;
            if (Reconnect && masterID <= ThereminoSystem.Masters.Count - 1)
            {
                _master = ThereminoSystem.Masters[masterID];
            }
            else
            {
                _master = new Master(masterID);
            }
			_master.Hid = new Theremino_HID();

			bool Detected = false;

			do 
            {
				Detected = false;

				// ------------------------------------------- Values for SECURITY_ATTRIBUTES structure
				_master.Hid.Security.lpSecurityDescriptor = 0;
				_master.Hid.Security.bInheritHandle = true;
				_master.Hid.Security.nLength = Strings.Len(_master.Hid.Security);


				// ------------------------------------------- The cbSize element of the MyDeviceInterfaceData structure
                // ------------------------------------------- must be set to the structure's size in bytes. The size is 28 bytes.
				_master.Hid.MyDeviceInterfaceData.cbSize = Marshal.SizeOf(_master.Hid.MyDeviceInterfaceData);
				bResult = Theremino_HAL.Theremino_HID.SetupDiEnumDeviceInterfaces(DeviceInfoSet, 
                                                                                  0, 
                                                                                  ref HidGuid, 
                                                                                  MemberIndex, 
                                                                                  ref _master.Hid.MyDeviceInterfaceData);

				Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("SetupDiEnumDeviceInterfaces");

				if (!bResult) LastDevice = true; 

				// ------------------------------------------- If a device exists, display the information returned.

				if (bResult) 
                {
					Theremino_HAL.Theremino_HID.DisplayResult("  DeviceInfoSet for device #" + MemberIndex.ToString() + ": ");
					Theremino_HAL.Theremino_HID.DisplayResult("  cbSize = " + _master.Hid.MyDeviceInterfaceData.cbSize.ToString());
					Theremino_HAL.Theremino_HID.DisplayResult("  Flags = " + Conversion.Hex(_master.Hid.MyDeviceInterfaceData.Flags));

					//******************************************************************************
					// SetupDiGetDeviceInterfaceDetail
					// Returns: an SP_DEVICE_INTERFACE_DETAIL_DATA structure
					// containing information about a device.
					// To retrieve the information, call this function twice.
					// The first time returns the size of the structure in Needed.
					// The second time returns a pointer to the data in DeviceInfoSet.
					// Requires:
					// A DeviceInfoSet returned by SetupDiGetClassDevs and
					// an SP_DEVICE_INTERFACE_DATA structure returned by SetupDiEnumDeviceInterfaces.
					//*******************************************************************************
					Int32 BufferSize = default(Int32);
					bResult = Theremino_HAL.Theremino_HID.SetupDiGetDeviceInterfaceDetail(DeviceInfoSet, ref _master.Hid.MyDeviceInterfaceData, IntPtr.Zero, 0, ref BufferSize, IntPtr.Zero);
					Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("SetupDiGetDeviceInterfaceDetail");
					Theremino_HAL.Theremino_HID.DisplayResult("  (OK to say too small)");
					Theremino_HAL.Theremino_HID.DisplayResult("  Required buffer size for the data: " + BufferSize);

					// ------------------------------------------- Store the structure's size.
					_master.Hid.MyDeviceInterfaceDetailData.cbSize = Strings.Len(_master.Hid.MyDeviceInterfaceDetailData);

					// ------------------------------------------- Allocate memory using the returned buffer size.
					IntPtr DetailDataBuffer = Marshal.AllocHGlobal(BufferSize);

					// ------------------------------------------- Store cbSize in the first 4 bytes of the array
					Marshal.WriteInt32(DetailDataBuffer, 4 + Marshal.SystemDefaultCharSize);
					//Debug.WriteLine("cbsize = " & MyDeviceInterfaceDetailData.cbSize)

					// ------------------------------------------- Call SetupDiGetDeviceInterfaceDetail again.
					// ------------------------------------------- This time, pass a pointer to DetailDataBuffer
					// ------------------------------------------- and the returned required buffer size.
					bResult = Theremino_HAL.Theremino_HID.SetupDiGetDeviceInterfaceDetail(DeviceInfoSet, ref _master.Hid.MyDeviceInterfaceData, DetailDataBuffer, BufferSize, ref BufferSize, IntPtr.Zero);
					Theremino_HAL.Theremino_HID.DisplayResultOfAPICall(" Result of second call: ");
					Theremino_HAL.Theremino_HID.DisplayResult("  MyDeviceInterfaceDetailData.cbSize: " + _master.Hid.MyDeviceInterfaceDetailData.cbSize.ToString());

					// ------------------------------------------- Convert the byte array to a string.
					// ------------------------------------------- Skip over cbsize (4 bytes) to get the address of the devicePathName.
					IntPtr pdevicePathName = new IntPtr(DetailDataBuffer.ToInt32() + 4);
					_master.Hid.DevicePathName = Marshal.PtrToStringAuto(pdevicePathName);
					Theremino_HAL.Theremino_HID.DisplayResult("  Device pathname: ");
					Theremino_HAL.Theremino_HID.DisplayResult("    " + _master.Hid.DevicePathName);


					//******************************************************************************
					// CreateFile
					// Returns: a handle that enables reading and writing to the device.
					// Requires:
					// The DevicePathName returned by SetupDiGetDeviceInterfaceDetail.
					//******************************************************************************
					_master.Hid.HIDHandle = Theremino_HAL.Theremino_HID.CreateFile(_master.Hid.DevicePathName, Theremino_HAL.Theremino_HID.GENERIC_WRITE, Theremino_HAL.Theremino_HID.FILE_SHARE_READ | Theremino_HAL.Theremino_HID.FILE_SHARE_WRITE, ref _master.Hid.Security, Theremino_HAL.Theremino_HID.OPEN_EXISTING, 0, 0);
					Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("CreateFile");
					Theremino_HAL.Theremino_HID.DisplayResult("  Returned handle: " + Conversion.Hex(_master.Hid.HIDHandle) + "h");


					// ---------------------------- Now we can find out if it's the device we're looking for.

					//******************************************************************************
					// HidD_GetAttributes
					// Requests information from the device.
					// Requires: The handle returned by CreateFile.
					// Returns: an HIDD_ATTRIBUTES structure containing
					// the Vendor ID, Product ID, and Product Version Number.
					// Use this information to determine if the detected device
					// is the one we're looking for.
					//******************************************************************************

					// ---------------------------- Set the Size property to the number of bytes in the structure.
					_master.Hid.DeviceAttributes.Size = Marshal.SizeOf(_master.Hid.DeviceAttributes);
					bResult = Theremino_HAL.Theremino_HID.HidD_GetAttributes(_master.Hid.HIDHandle, ref _master.Hid.DeviceAttributes);

					if ((Theremino_HAL.Theremino_HID.USB_Results != null)) 
                    {
						Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("HidD_GetAttributes");
						if (bResult) 
                        {
							Theremino_HAL.Theremino_HID.DisplayResult("  HIDD_ATTRIBUTES structure filled without error.");
						}
						else 
                        {
							Theremino_HAL.Theremino_HID.DisplayResult("  Error in filling HIDD_ATTRIBUTES structure.");
						}
						Theremino_HAL.Theremino_HID.DisplayResult("  Structure size: " + _master.Hid.DeviceAttributes.Size);
						Theremino_HAL.Theremino_HID.DisplayResult("  Vendor ID: " + Conversion.Hex(_master.Hid.DeviceAttributes.VendorID));
						Theremino_HAL.Theremino_HID.DisplayResult("  Product ID: " + Conversion.Hex(_master.Hid.DeviceAttributes.ProductID));
						Theremino_HAL.Theremino_HID.DisplayResult("  Version Number: " + Conversion.Hex(_master.Hid.DeviceAttributes.VersionNumber));
					}

					// ---------------------------------------- Find out if the device matches the one we're looking for.
					if ((_master.Hid.DeviceAttributes.VendorID == USB_VendorID) & (_master.Hid.DeviceAttributes.ProductID == USB_ProductID)) 
                    {
						// -------------------------------- It's the desired device.
						Theremino_HAL.Theremino_HID.DisplayResult("  My device detected");
						Detected = true;
					}
					else 
                    {
						// -------------------------------- If it's not the one we want, close its handle.
						bResult = Theremino_HAL.Theremino_HID.CloseHandle(_master.Hid.HIDHandle);
						Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("CloseHandle");
					}
				}
				// -------------------------------------------- Keep looking until we find the device or there are no more left to examine.
				MemberIndex = MemberIndex + 1;



				if (Detected) 
                {
					// -------------------------------- Learn the capabilities of the device
					_master.Hid.GetDeviceCapabilities();
					// -------------------------------- Get another handle for the overlapped ReadFiles.
					_master.Hid.ReadHandle = Theremino_HAL.Theremino_HID.CreateFile(_master.Hid.DevicePathName,  Theremino_HAL.Theremino_HID.GENERIC_READ, Theremino_HAL.Theremino_HID.FILE_SHARE_READ | Theremino_HAL.Theremino_HID.FILE_SHARE_WRITE, ref _master.Hid.Security, Theremino_HAL.Theremino_HID.OPEN_EXISTING, Theremino_HAL.Theremino_HID.FILE_FLAG_OVERLAPPED, 0);

					Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("CreateFile, ReadHandle");
					Theremino_HAL.Theremino_HID.DisplayResult("  Returned handle: " + Conversion.Hex(_master.Hid.ReadHandle) + "h");


					_master.Hid.PrepareForOverlappedTransfer();

					// ---------------------------------------- insert Master and Hid in the Masters list
					_master.Hid.MyDeviceDetected = true;

                    // ---------------------------------------- reconnect or prepare a new Master
                    if (Reconnect)
                    {
                        masterID += 1;
                    }
                    else
                    {
                        ThereminoSystem.Masters.Add(_master);
                        masterID += 1;
                        // ------------------------------------- prepare a new master
                        _master = new Master(masterID);
                        _master.Hid = new Theremino_HID();
                    }
				}
			}
			while (!(LastDevice == true));

			// ------------------------------------------------ Free the memory reserved for the
			// ------------------------------------------------ DeviceInfoSet returned by SetupDiGetClassDevs.
			iResult = Theremino_HAL.Theremino_HID.SetupDiDestroyDeviceInfoList(DeviceInfoSet);
			Theremino_HAL.Theremino_HID.DisplayResultOfAPICall("DestroyDeviceInfoList");

		}


	}
}
